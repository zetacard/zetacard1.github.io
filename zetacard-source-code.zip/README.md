# ZetaCard — Complete, Independent Digital Card & Business Productivity Ecosystem

**Founder & Principal Architect:** Shahid Tufail  
**Reference Platform:** https://zeta-card.base44.app/  
**Core Technologies:** React 19, TypeScript, Tailwind CSS v4, Vite, Node.js Express, Google GenAI SDK (Gemini 3.8 Flash), Web NFC API (NDEFReader), QRCode, Web Crypto API.

---

## 1. Overview & Architecture

ZetaCard is a production-ready, independent digital card ecosystem engineered to deliver 100% data ownership and freedom without proprietary builder lock-in.

### Core Ecosystem Modules:
1. **Digital Business & Visiting Cards**: Complete vCard 3.0 generation, one-tap address book download, direct communication channels (phone, email, WhatsApp, maps), social links, services & pricing showcase.
2. **Luxury Wedding Invitations**: Bride and groom feature cards, live countdown timers, ceremony and reception details, Google Maps integration, love story narrative, dress code specifications, and interactive RSVP submission.
3. **Birthday & Milestone Invitations**: Honoree age milestones, party hours and venue, festive confetti animations, custom party themes, and RSVP tracking.
4. **Conferences, Summits & Galas**: Multi-track agendas, keynote speaker rosters, virtual live-stream access, and ticket booking links.
5. **Restaurant Digital Menus**: Touchless tabletop QR menus with categorized courses (Starters, Mains, Desserts, Beverages), dietary indicator tags (Vegetarian, Vegan, Gluten-Free, Spicy, Chef's Special), and table reservation forms.
6. **100+ Template Marketplace**: Over 20 genuinely distinct templates per category (Modern Executive, Silicon Tech, Noir Gold, Swiss Minimal, Brutalist Bold, Emerald Bio, Neon Synthwave, and more).
7. **Advanced Visual Card Editor**: Real-time smartphone frame preview, custom font selection, color pickers, cover banner & avatar configuration, and slug customization.
8. **QR Code & Social Sharing System**: Dynamic QR code generator with high-res PNG download, SVG export, clipboard copy, and native Web Share integration.
9. **Physical NFC Integration**: Real Web NFC API (`NDEFReader`) execution to write card URLs to physical NTAG213 / NTAG215 / NTAG216 tags, cards, or stickers, with step-by-step guides for iOS and Android.
10. **Appointments & Bookings Management**: Double-booking conflict prevention, pending/confirmed/cancelled statuses, and automatic sync with client CRM.
11. **Contacts CRM**: Automatic lead capture from public card messages, RSVP submissions, and appointment bookings, with CSV export.
12. **Personal Productivity Suite**: Daily planner, priority-based tasks (High/Medium/Low), due dates, and agenda overview.
13. **Gemini AI Copilot**: Secure server-side endpoint (`/api/ai/generate`) utilizing `@google/genai` with model `gemini-3.8-flash` to write bios, taglines, invitations, and menu descriptions.
14. **Founder Administration Panel**: Dedicated oversight for Shahid Tufail with ecosystem analytics, card moderation, user directory, and system health checks.

---

## 2. Independent Data Persistence & Ownership

ZetaCard stores all cards, bookings, contacts, tasks, and inquiries in a resilient client-side persistent storage engine (`src/services/db.ts`).

- **Instant Full System JSON Backup**: Export the entire database with a single click from the Dashboard Settings.
- **Instant Restore**: Upload your backup JSON on any device to restore your exact portfolio, appointments, and contacts.
- **Zero Cloud Lock-in**: Run the application completely on your own domain or server without mandatory cloud subscriptions.

---

## 3. Local Development & Deployment

### Run Locally:
```bash
# Install dependencies
npm install

# Start Vite dev server on port 3000
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

### Environment Configuration:
Create a `.env` file based on `.env.example`:
```env
GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
PORT=3000
```
