import React, { useState, useEffect } from 'react';
import { User, Card, Template, CardCategory } from './types';
import { authService, subscribeAuth } from './services/auth';
import { dbService } from './services/db';
import { LandingPage } from './components/landing/LandingPage';
import { TemplateGallery } from './components/templates/TemplateGallery';
import { UserDashboard } from './components/dashboard/UserDashboard';
import { CardEditor } from './components/editor/CardEditor';
import { PublicCardView } from './components/cards/PublicCardView';
import { AdminPanel } from './components/admin/AdminPanel';
import { AuthModal } from './components/auth/AuthModal';
import {
  Sparkles,
  Layers,
  LayoutDashboard,
  Shield,
  Plus,
  LogOut,
  User as UserIcon,
  Globe,
  Radio,
  ExternalLink,
  Download,
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(authService.getCurrentUser());
  const [currentView, setCurrentView] = useState<'landing' | 'templates' | 'dashboard' | 'editor' | 'public_card' | 'admin'>('landing');
  const [activeEditingCard, setActiveEditingCard] = useState<Card | null>(null);
  const [activeCardSlug, setActiveCardSlug] = useState<string>('shahid-tufail');
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Subscribe to auth changes
  useEffect(() => {
    const unsub = subscribeAuth((user) => setCurrentUser(user));
    return unsub;
  }, []);

  // Check URL query parameters for public card link
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const cardParam = params.get('card');
      if (cardParam) {
        setActiveCardSlug(cardParam);
        setCurrentView('public_card');
      }
    }
  }, []);

  // Navigation handlers
  const handleStartFromTemplate = (template: Template) => {
    const newCard: Card = {
      id: `card-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: currentUser?.id || 'user-guest',
      slug: `${template.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Math.floor(100 + Math.random() * 900)}`,
      category: template.category,
      templateId: template.id,
      status: 'draft',
      title: template.sampleData.title || template.name,
      subtitle: template.sampleData.subtitle || '',
      company: template.sampleData.company || '',
      bio: template.sampleData.bio || template.description,
      email: currentUser?.email || 'contact@example.com',
      phone: currentUser?.phone || '+1 (555) 000-0000',
      website: template.sampleData.website || 'https://zeta-card.base44.app/',
      address: template.sampleData.address || '',
      coverImageUrl: template.previewImage,
      profileImageUrl: currentUser?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
      socialLinks: [
        { id: '1', platform: 'linkedin', url: 'https://linkedin.com' },
        { id: '2', platform: 'twitter', url: 'https://x.com' },
      ],
      theme: template.theme,
      weddingDetails: template.sampleData.weddingDetails,
      birthdayDetails: template.sampleData.birthdayDetails,
      eventDetails: template.sampleData.eventDetails,
      menuCategories: template.sampleData.menuCategories,
      menuItems: template.sampleData.menuItems,
      services: template.sampleData.services,
      viewCount: 0,
      qrScanCount: 0,
      vCardDownloadCount: 0,
      nfcEnabled: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setActiveEditingCard(newCard);
    setCurrentView('editor');
  };

  const handleCreateNewCard = (category: CardCategory = 'business') => {
    const newCard: Card = {
      id: `card-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: currentUser?.id || 'user-guest',
      slug: `my-card-${Math.floor(1000 + Math.random() * 9000)}`,
      category,
      templateId: `${category}-custom-default`,
      status: 'draft',
      title: currentUser?.name || 'My New Digital Card',
      subtitle: 'Professional Headline',
      company: currentUser?.company || 'My Venture',
      bio: 'Share your background, achievements, and unique value proposition.',
      email: currentUser?.email || 'hello@example.com',
      phone: currentUser?.phone || '+1 (555) 123-4567',
      website: 'https://zeta-card.base44.app/',
      address: 'San Francisco, CA',
      coverImageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
      profileImageUrl: currentUser?.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
      socialLinks: [
        { id: '1', platform: 'linkedin', url: 'https://linkedin.com' },
        { id: '2', platform: 'twitter', url: 'https://x.com' },
      ],
      theme: {
        primaryColor: '#0ea5e9',
        secondaryColor: '#38bdf8',
        accentColor: '#f59e0b',
        backgroundColor: '#0f172a',
        textColor: '#f8fafc',
        fontFamily: 'Outfit',
        cardStyle: 'glass',
        borderRadius: 'xl',
        layout: 'standard',
      },
      viewCount: 0,
      qrScanCount: 0,
      vCardDownloadCount: 0,
      nfcEnabled: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setActiveEditingCard(newCard);
    setCurrentView('editor');
  };

  // If currently in public standalone card view
  if (currentView === 'public_card') {
    return (
      <PublicCardView
        cardSlug={activeCardSlug}
        onGoHome={() => {
          // Clear query param
          if (typeof window !== 'undefined' && window.history.pushState) {
            window.history.pushState({}, '', window.location.pathname);
          }
          setCurrentView('landing');
        }}
        onGoDashboard={() => {
          if (typeof window !== 'undefined' && window.history.pushState) {
            window.history.pushState({}, '', window.location.pathname);
          }
          setCurrentView('dashboard');
        }}
      />
    );
  }

  // If in Card Editor
  if (currentView === 'editor' && activeEditingCard) {
    return (
      <CardEditor
        initialCard={activeEditingCard}
        onBack={() => setCurrentView('dashboard')}
        onSaved={(saved) => {
          setActiveEditingCard(saved);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Global Navigation Header */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800/80 px-4 sm:px-8 py-3.5 flex items-center justify-between">
        {/* Brand Logo & Founder Badge */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('landing')}
            className="flex items-center gap-2.5 text-left cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-black font-extrabold shadow-lg shadow-cyan-500/30 group-hover:scale-105 transition-transform">
              <span className="text-lg tracking-tighter">Z</span>
            </div>
            <div>
              <div className="text-base font-extrabold tracking-tight text-white flex items-center gap-1.5">
                <span>ZetaCard</span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Pro
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-medium">
                by Shahid Tufail
              </div>
            </div>
          </button>
        </div>

        {/* Center Nav Links */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-900/60 border border-slate-800/80 p-1 rounded-2xl">
          <button
            onClick={() => setCurrentView('landing')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              currentView === 'landing' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Overview
          </button>

          <button
            onClick={() => setCurrentView('templates')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              currentView === 'templates' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            100+ Templates
          </button>

          <button
            onClick={() => setCurrentView('dashboard')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              currentView === 'dashboard' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Dashboard
          </button>

          {currentUser?.role === 'admin' && (
            <button
              onClick={() => setCurrentView('admin')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                currentView === 'admin' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'text-amber-400/80 hover:text-amber-300'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              Admin
            </button>
          )}
        </nav>

        {/* Right User Bar / Login */}
        <div className="flex items-center gap-3">
          {currentUser ? (
            <div className="flex items-center gap-2.5">
              <a
                href="/zetacard-source-code.zip"
                download="zetacard-source-code.zip"
                className="hidden lg:flex px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-cyan-400 text-xs font-semibold items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                title="Download Complete Source Code (.ZIP)"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Source .ZIP</span>
              </a>

              <button
                onClick={() => handleCreateNewCard('business')}
                className="hidden sm:flex px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Create Card
              </button>

              <button
                onClick={() => setCurrentView('dashboard')}
                className="flex items-center gap-2 p-1 pl-2 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer"
              >
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-bold text-white truncate max-w-[120px]">{currentUser.name}</div>
                  <div className="text-[10px] text-cyan-400 capitalize">{currentUser.role}</div>
                </div>
                <img
                  src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'}
                  alt=""
                  className="w-8 h-8 rounded-xl object-cover bg-slate-800"
                />
              </button>

              <button
                onClick={() => authService.logout()}
                className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-900 transition-all cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowAuthModal(true)}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <UserIcon className="w-3.5 h-3.5" />
              Sign In / Register
            </button>
          )}
        </div>
      </header>

      {/* Main Dynamic View Outlet */}
      <main className="flex-1">
        {currentView === 'landing' && (
          <LandingPage
            onExploreTemplates={(cat) => {
              setCurrentView('templates');
            }}
            onOpenDashboard={() => setCurrentView('dashboard')}
            onOpenCardBySlug={(slug) => {
              setActiveCardSlug(slug);
              setCurrentView('public_card');
            }}
          />
        )}

        {currentView === 'templates' && (
          <TemplateGallery onSelectTemplate={handleStartFromTemplate} />
        )}

        {currentView === 'dashboard' && currentUser && (
          <UserDashboard
            user={currentUser}
            onEditCard={(c) => {
              setActiveEditingCard(c);
              setCurrentView('editor');
            }}
            onCreateNewCard={handleCreateNewCard}
            onOpenAdmin={() => setCurrentView('admin')}
          />
        )}

        {currentView === 'admin' && (
          <AdminPanel
            onBack={() => setCurrentView('dashboard')}
            onViewCard={(c) => {
              setActiveCardSlug(c.slug);
              setCurrentView('public_card');
            }}
          />
        )}
      </main>

      {/* Authentication Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={(u) => {
          setCurrentUser(u);
          setCurrentView('dashboard');
        }}
      />
    </div>
  );
}
