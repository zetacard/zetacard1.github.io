import React, { useState, useEffect } from 'react';
import { Card } from '../../types';
import { dbService } from '../../services/db';
import { CardRenderer } from './CardRenderer';
import { QRModal } from '../qr/QRModal';
import { NFCModal } from '../qr/NFCModal';
import { BookingModal } from '../booking/BookingModal';
import { downloadVCard } from '../../services/vcard';
import {
  Share2,
  Bookmark,
  Calendar,
  Radio,
  ArrowLeft,
  Sparkles,
} from 'lucide-react';

interface PublicCardViewProps {
  cardSlug: string;
  onGoHome: () => void;
  onGoDashboard?: () => void;
}

export const PublicCardView: React.FC<PublicCardViewProps> = ({
  cardSlug,
  onGoHome,
  onGoDashboard,
}) => {
  const [card, setCard] = useState<Card | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showNfcModal, setShowNfcModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);

  useEffect(() => {
    let found = dbService.getCardBySlug(cardSlug);
    if (!found) {
      found = dbService.getCardById(cardSlug);
    }
    if (found) {
      setCard(found);
      dbService.incrementCardViews(found.id);
    }
  }, [cardSlug]);

  if (!card) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-800 text-slate-500 flex items-center justify-center mb-4">
          <Sparkles className="w-8 h-8 text-cyan-400" />
        </div>
        <h2 className="text-xl font-bold">Card Not Found</h2>
        <p className="text-xs text-slate-400 mt-1 max-w-sm">
          The requested card link <span className="font-mono text-cyan-300">"{cardSlug}"</span> does not exist or may have been unlinked.
        </p>
        <button
          onClick={onGoHome}
          className="mt-6 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs cursor-pointer"
        >
          Return to ZetaCard Home
        </button>
      </div>
    );
  }

  const handleSaveContact = () => {
    downloadVCard(card);
    dbService.incrementCardVcard(card.id);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-start relative">
      {/* Top Floating App Bar */}
      <header className="sticky top-0 z-30 w-full max-w-xl mx-auto px-4 py-2.5 bg-slate-950/70 backdrop-blur-md flex items-center justify-between border-b border-slate-800/60">
        <button
          onClick={onGoHome}
          className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white transition-all cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>ZetaCard</span>
        </button>

        <div className="flex items-center gap-2">
          {onGoDashboard && (
            <button
              onClick={onGoDashboard}
              className="text-[11px] text-cyan-400 font-semibold hover:underline cursor-pointer"
            >
              Dashboard
            </button>
          )}
          <button
            onClick={() => setShowQrModal(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white cursor-pointer"
            title="QR Code"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main Full-width/Mobile Responsive Card */}
      <div className="w-full max-w-xl mx-auto flex-1 shadow-2xl relative">
        <CardRenderer
          card={card}
          isPublicView={true}
          onOpenBooking={() => setShowBookingModal(true)}
          onOpenShare={() => setShowQrModal(true)}
          onOpenNfc={() => setShowNfcModal(true)}
        />
      </div>

      {/* Floating Bottom Quick Action Dock */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 w-[92%] max-w-md bg-slate-900/90 backdrop-blur-xl border border-slate-700/60 rounded-2xl p-2 shadow-2xl flex items-center justify-between gap-1.5">
        <button
          onClick={handleSaveContact}
          className="flex-1 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
        >
          <Bookmark className="w-3.5 h-3.5" />
          Save vCard
        </button>

        <button
          onClick={() => setShowBookingModal(true)}
          className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
        >
          <Calendar className="w-3.5 h-3.5 text-cyan-400" />
          Book Slot
        </button>

        <button
          onClick={() => setShowQrModal(true)}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all cursor-pointer"
          title="Share QR"
        >
          <Share2 className="w-4 h-4 text-purple-400" />
        </button>

        {card.nfcEnabled && (
          <button
            onClick={() => setShowNfcModal(true)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all cursor-pointer"
            title="Write NFC"
          >
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
          </button>
        )}
      </div>

      {/* Modals */}
      <QRModal
        card={card}
        isOpen={showQrModal}
        onClose={() => setShowQrModal(false)}
        onOpenNfc={() => setShowNfcModal(true)}
      />

      <NFCModal
        card={card}
        isOpen={showNfcModal}
        onClose={() => setShowNfcModal(false)}
      />

      <BookingModal
        card={card}
        isOpen={showBookingModal}
        onClose={() => setShowBookingModal(false)}
      />
    </div>
  );
};
