import React, { useState } from 'react';
import { Card } from '../../types';
import { CardRenderer } from './CardRenderer';
import { Smartphone, Monitor, Maximize2, ExternalLink } from 'lucide-react';

interface CardMockupProps {
  card: Card;
  onOpenBooking?: () => void;
  onOpenShare?: () => void;
  onOpenNfc?: () => void;
}

export const CardMockup: React.FC<CardMockupProps> = ({
  card,
  onOpenBooking,
  onOpenShare,
  onOpenNfc,
}) => {
  const [deviceMode, setDeviceMode] = useState<'mobile' | 'full'>('mobile');

  return (
    <div className="flex flex-col items-center w-full">
      {/* Device Mode Switcher Toolbar */}
      <div className="flex items-center gap-2 mb-4 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 text-xs text-slate-400">
        <button
          onClick={() => setDeviceMode('mobile')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
            deviceMode === 'mobile'
              ? 'bg-cyan-500/20 text-cyan-400 font-semibold border border-cyan-500/30'
              : 'hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          Mobile Frame
        </button>

        <button
          onClick={() => setDeviceMode('full')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
            deviceMode === 'full'
              ? 'bg-cyan-500/20 text-cyan-400 font-semibold border border-cyan-500/30'
              : 'hover:text-white'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          Full Width
        </button>

        <a
          href={`?card=${card.slug}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:text-white transition-all ml-1"
          title="Open in new window"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          Live Tab
        </a>
      </div>

      {/* Frame Rendering */}
      {deviceMode === 'mobile' ? (
        <div className="relative w-full max-w-[390px] h-[780px] bg-slate-950 rounded-[48px] p-3 shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700/50 flex flex-col overflow-hidden">
          {/* Dynamic Island / Speaker Pill */}
          <div className="absolute top-5 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-30 flex items-center justify-between px-3">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700" />
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </div>

          {/* Screen Content */}
          <div className="w-full h-full rounded-[38px] overflow-y-auto overflow-x-hidden relative scrollbar-none bg-slate-950">
            <CardRenderer
              card={card}
              onOpenBooking={onOpenBooking}
              onOpenShare={onOpenShare}
              onOpenNfc={onOpenNfc}
            />
          </div>

          {/* Bottom Home Indicator */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-32 h-1 bg-white/30 rounded-full z-30 pointer-events-none" />
        </div>
      ) : (
        <div className="w-full max-w-2xl min-h-[600px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950">
          <CardRenderer
            card={card}
            onOpenBooking={onOpenBooking}
            onOpenShare={onOpenShare}
            onOpenNfc={onOpenNfc}
          />
        </div>
      )}
    </div>
  );
};
