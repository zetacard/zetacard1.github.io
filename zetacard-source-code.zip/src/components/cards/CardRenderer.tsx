import React, { useState, useEffect } from 'react';
import { Card, MenuItem } from '../../types';
import {
  Phone,
  Mail,
  Globe,
  MapPin,
  Calendar,
  Clock,
  Share2,
  Download,
  Bookmark,
  CheckCircle,
  ExternalLink,
  Heart,
  Sparkles,
  Utensils,
  ChevronRight,
  Send,
  Linkedin,
  Twitter,
  Instagram,
  Github,
  Youtube,
  MessageCircle,
  PartyPopper,
  Radio,
} from 'lucide-react';
import { downloadVCard } from '../../services/vcard';
import { dbService } from '../../services/db';
import confetti from 'canvas-confetti';

interface CardRendererProps {
  card: Card;
  isPublicView?: boolean;
  onOpenBooking?: () => void;
  onOpenShare?: () => void;
  onOpenNfc?: () => void;
}

export const CardRenderer: React.FC<CardRendererProps> = ({
  card,
  isPublicView = false,
  onOpenBooking,
  onOpenShare,
  onOpenNfc,
}) => {
  const { theme, category } = card;

  // Active menu category tab for restaurant cards
  const [activeMenuCat, setActiveMenuCat] = useState<string>(
    card.menuCategories?.[0]?.id || 'all'
  );

  // RSVP Form state
  const [rsvpSubmitted, setRsvpSubmitted] = useState(false);
  const [rsvpName, setRsvpName] = useState('');
  const [rsvpEmail, setRsvpEmail] = useState('');
  const [rsvpStatus, setRsvpStatus] = useState<'attending' | 'declined'>('attending');
  const [rsvpGuests, setRsvpGuests] = useState('1');
  const [rsvpDiet, setRsvpDiet] = useState('');

  // Contact / Enquiry form state
  const [enqName, setEnqName] = useState('');
  const [enqEmail, setEnqEmail] = useState('');
  const [enqMessage, setEnqMessage] = useState('');
  const [enqSent, setEnqSent] = useState(false);

  // Countdown timer for wedding & event
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const targetDate = card.weddingDetails?.weddingDate || card.eventDetails?.startDate;
    if (!targetDate) return;

    const interval = setInterval(() => {
      const target = new Date(targetDate).getTime();
      const now = new Date().getTime();
      const difference = target - now;

      if (difference <= 0) {
        clearInterval(interval);
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      } else {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, minutes, seconds });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [card.weddingDetails?.weddingDate, card.eventDetails?.startDate]);

  const handleSaveContact = () => {
    downloadVCard(card);
    dbService.incrementCardVcard(card.id);
  };

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const handleRsvpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rsvpName || !rsvpEmail) return;

    dbService.createEnquiry({
      cardId: card.id,
      ownerId: card.userId,
      senderName: rsvpName,
      senderEmail: rsvpEmail,
      subject: `RSVP from ${rsvpName} (${rsvpStatus})`,
      message: `Status: ${rsvpStatus.toUpperCase()} | Guests: ${rsvpGuests} | Dietary/Notes: ${rsvpDiet || 'None'}`,
      status: 'unread',
    });

    setRsvpSubmitted(true);
    triggerConfetti();
  };

  const handleEnquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!enqName || !enqEmail || !enqMessage) return;

    dbService.createEnquiry({
      cardId: card.id,
      ownerId: card.userId,
      senderName: enqName,
      senderEmail: enqEmail,
      subject: `New Message from ${enqName}`,
      message: enqMessage,
      status: 'unread',
    });

    setEnqSent(true);
  };

  // Font styling
  const fontStyle = {
    fontFamily: theme.fontFamily === 'Space Grotesk'
      ? '"Space Grotesk", sans-serif'
      : theme.fontFamily === 'Cinzel'
      ? '"Cinzel", serif'
      : theme.fontFamily === 'Playfair Display'
      ? '"Playfair Display", serif'
      : theme.fontFamily === 'Great Vibes'
      ? '"Great Vibes", cursive'
      : theme.fontFamily === 'Outfit'
      ? '"Outfit", sans-serif'
      : '"Inter", sans-serif',
  };

  // Social icon mapping
  const renderSocialIcon = (platform: string) => {
    switch (platform) {
      case 'linkedin':
        return <Linkedin className="w-4 h-4" />;
      case 'twitter':
        return <Twitter className="w-4 h-4" />;
      case 'instagram':
        return <Instagram className="w-4 h-4" />;
      case 'github':
        return <Github className="w-4 h-4" />;
      case 'youtube':
        return <Youtube className="w-4 h-4" />;
      case 'whatsapp':
        return <MessageCircle className="w-4 h-4" />;
      default:
        return <Globe className="w-4 h-4" />;
    }
  };

  // Card theme classes
  const isDark = theme.backgroundColor.toLowerCase() !== '#ffffff' && !theme.backgroundColor.toLowerCase().includes('fff');

  return (
    <div
      className="w-full min-h-full transition-all duration-300 relative overflow-hidden select-text text-left"
      style={{
        ...fontStyle,
        backgroundColor: theme.backgroundColor,
        color: theme.textColor,
      }}
    >
      {/* Background ambient gradient glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full blur-3xl opacity-20 pointer-events-none"
        style={{
          background: `radial-gradient(circle, ${theme.primaryColor} 0%, ${theme.secondaryColor} 100%)`,
        }}
      />

      {/* Header Cover Banner */}
      <div className="relative w-full h-44 sm:h-52 overflow-hidden bg-slate-900">
        <img
          src={card.coverImageUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80'}
          alt={card.title}
          className="w-full h-full object-cover opacity-90 transition-transform duration-700 hover:scale-105"
        />
        <div
          className="absolute inset-0 bg-gradient-to-t"
          style={{
            backgroundImage: `linear-gradient(to top, ${theme.backgroundColor}, transparent)`,
          }}
        />

        {/* Top Badges */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          <span
            className="px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider rounded-full backdrop-blur-md"
            style={{
              backgroundColor: 'rgba(0,0,0,0.5)',
              color: theme.accentColor || '#ffffff',
              border: `1px solid ${theme.primaryColor}40`,
            }}
          >
            {category}
          </span>
          {card.nfcEnabled && (
            <span
              className="px-2 py-0.5 text-xs font-medium rounded-full backdrop-blur-md flex items-center gap-1"
              style={{
                backgroundColor: 'rgba(0,0,0,0.5)',
                color: '#38bdf8',
                border: '1px solid rgba(56,189,248,0.4)',
              }}
            >
              <Radio className="w-3 h-3 animate-pulse" />
              NFC Active
            </span>
          )}
        </div>
      </div>

      {/* Main Container */}
      <div className="relative px-5 sm:px-6 pb-24 -mt-16 z-10 max-w-xl mx-auto">
        {/* Profile Avatar / Seal */}
        <div className="flex items-end justify-between mb-4">
          <div className="relative">
            <div
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden shadow-2xl p-1"
              style={{
                background: `linear-gradient(135deg, ${theme.primaryColor}, ${theme.secondaryColor})`,
              }}
            >
              <img
                src={card.profileImageUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80'}
                alt={card.title}
                className="w-full h-full object-cover rounded-xl bg-slate-800"
              />
            </div>
            {category === 'wedding' && (
              <span className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-rose-500 text-white shadow-lg">
                <Heart className="w-4 h-4 fill-white" />
              </span>
            )}
            {category === 'birthday' && (
              <span className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-amber-500 text-white shadow-lg">
                <PartyPopper className="w-4 h-4" />
              </span>
            )}
            {category === 'restaurant' && (
              <span className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-emerald-500 text-white shadow-lg">
                <Utensils className="w-4 h-4" />
              </span>
            )}
          </div>

          {/* Quick Header Action Buttons */}
          <div className="flex items-center gap-2 mb-2">
            {onOpenShare && (
              <button
                onClick={onOpenShare}
                className="p-2.5 rounded-xl transition-all duration-200 border cursor-pointer hover:opacity-90 active:scale-95"
                style={{
                  backgroundColor: `${theme.primaryColor}20`,
                  borderColor: `${theme.primaryColor}50`,
                  color: theme.textColor,
                }}
                title="Share & QR Code"
              >
                <Share2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={handleSaveContact}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold transition-all duration-200 flex items-center gap-1.5 shadow-lg cursor-pointer hover:opacity-90 active:scale-95"
              style={{
                background: `linear-gradient(135deg, ${theme.primaryColor}, ${theme.secondaryColor})`,
                color: '#ffffff',
              }}
            >
              <Bookmark className="w-3.5 h-3.5" />
              Save vCard
            </button>
          </div>
        </div>

        {/* Title, Subtitle, & Role */}
        <div className="mb-5">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight leading-tight">
            {card.title}
          </h1>
          {card.subtitle && (
            <p
              className="text-sm sm:text-base font-medium mt-1 opacity-90"
              style={{ color: theme.secondaryColor }}
            >
              {card.subtitle}
            </p>
          )}
          {card.company && (
            <div className="flex items-center gap-1.5 text-xs mt-1.5 opacity-75 font-medium">
              <span>{card.company}</span>
              {card.address && <span>• {card.address}</span>}
            </div>
          )}
        </div>

        {/* Bio / Description */}
        {card.bio && (
          <div
            className="p-4 rounded-2xl mb-6 text-sm leading-relaxed border backdrop-blur-md"
            style={{
              backgroundColor: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.03)',
              borderColor: `${theme.primaryColor}30`,
            }}
          >
            <p className="whitespace-pre-line opacity-90">{card.bio}</p>
          </div>
        )}

        {/* Direct Contact Links Grid */}
        <div className="grid grid-cols-2 gap-2.5 mb-6">
          {card.phone && (
            <a
              href={`tel:${card.phone}`}
              className="p-3 rounded-xl border flex items-center gap-3 transition-all hover:translate-y-[-1px] text-xs font-medium"
              style={{
                backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
                borderColor: `${theme.primaryColor}25`,
              }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${theme.primaryColor}20`, color: theme.primaryColor }}
              >
                <Phone className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <span className="block opacity-60 text-[10px] uppercase tracking-wider">Phone</span>
                <span className="truncate block font-semibold">{card.phone}</span>
              </div>
            </a>
          )}

          {card.email && (
            <a
              href={`mailto:${card.email}`}
              className="p-3 rounded-xl border flex items-center gap-3 transition-all hover:translate-y-[-1px] text-xs font-medium"
              style={{
                backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
                borderColor: `${theme.primaryColor}25`,
              }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${theme.primaryColor}20`, color: theme.primaryColor }}
              >
                <Mail className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <span className="block opacity-60 text-[10px] uppercase tracking-wider">Email</span>
                <span className="truncate block font-semibold">{card.email}</span>
              </div>
            </a>
          )}

          {card.website && (
            <a
              href={card.website.startsWith('http') ? card.website : `https://${card.website}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl border flex items-center gap-3 transition-all hover:translate-y-[-1px] text-xs font-medium"
              style={{
                backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
                borderColor: `${theme.primaryColor}25`,
              }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${theme.primaryColor}20`, color: theme.primaryColor }}
              >
                <Globe className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <span className="block opacity-60 text-[10px] uppercase tracking-wider">Website</span>
                <span className="truncate block font-semibold">{card.website.replace(/^https?:\/\//, '')}</span>
              </div>
            </a>
          )}

          {card.mapsUrl && (
            <a
              href={card.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl border flex items-center gap-3 transition-all hover:translate-y-[-1px] text-xs font-medium"
              style={{
                backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
                borderColor: `${theme.primaryColor}25`,
              }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${theme.primaryColor}20`, color: theme.primaryColor }}
              >
                <MapPin className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <span className="block opacity-60 text-[10px] uppercase tracking-wider">Directions</span>
                <span className="truncate block font-semibold">Open Maps</span>
              </div>
            </a>
          )}
        </div>

        {/* Social Links Row */}
        {card.socialLinks && card.socialLinks.length > 0 && (
          <div className="mb-6">
            <h4 className="text-xs uppercase tracking-wider opacity-60 font-semibold mb-2.5">
              Connect Across Networks
            </h4>
            <div className="flex flex-wrap gap-2">
              {card.socialLinks.map((link) => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2 border transition-all hover:scale-105 active:scale-95"
                  style={{
                    backgroundColor: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)',
                    borderColor: `${theme.primaryColor}30`,
                    color: theme.textColor,
                  }}
                >
                  <span style={{ color: theme.primaryColor }}>{renderSocialIcon(link.platform)}</span>
                  <span>{link.label || link.platform}</span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* ================= CATEGORY SPECIFIC MODULES ================= */}

        {/* 1. WEDDING MODULE */}
        {category === 'wedding' && card.weddingDetails && (
          <div className="space-y-6 my-6">
            {/* Bride & Groom Feature Banner */}
            <div
              className="p-6 rounded-2xl text-center border relative overflow-hidden"
              style={{
                backgroundColor: `${theme.primaryColor}12`,
                borderColor: `${theme.primaryColor}40`,
              }}
            >
              <Heart className="w-8 h-8 mx-auto mb-2 text-rose-500 fill-rose-500 animate-pulse" />
              <div className="text-2xl sm:text-3xl font-serif font-bold text-rose-400">
                {card.weddingDetails.brideName} & {card.weddingDetails.groomName}
              </div>
              <div className="text-xs uppercase tracking-widest mt-2 opacity-75">
                Are getting married
              </div>

              {/* Countdown Timer */}
              <div className="grid grid-cols-4 gap-2 mt-5 max-w-xs mx-auto">
                <div className="p-2 rounded-xl bg-black/30 border border-white/10">
                  <div className="text-xl font-bold">{timeLeft.days}</div>
                  <div className="text-[10px] opacity-60 uppercase">Days</div>
                </div>
                <div className="p-2 rounded-xl bg-black/30 border border-white/10">
                  <div className="text-xl font-bold">{timeLeft.hours}</div>
                  <div className="text-[10px] opacity-60 uppercase">Hours</div>
                </div>
                <div className="p-2 rounded-xl bg-black/30 border border-white/10">
                  <div className="text-xl font-bold">{timeLeft.minutes}</div>
                  <div className="text-[10px] opacity-60 uppercase">Mins</div>
                </div>
                <div className="p-2 rounded-xl bg-black/30 border border-white/10">
                  <div className="text-xl font-bold">{timeLeft.seconds}</div>
                  <div className="text-[10px] opacity-60 uppercase">Secs</div>
                </div>
              </div>
            </div>

            {/* Wedding Schedule & Location */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                className="p-4 rounded-2xl border"
                style={{
                  backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
                  borderColor: `${theme.primaryColor}30`,
                }}
              >
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold opacity-70 mb-2">
                  <Calendar className="w-4 h-4 text-rose-400" />
                  Ceremony & Reception
                </div>
                <div className="text-sm font-semibold">{card.weddingDetails.ceremonyTime}</div>
                <div className="text-xs opacity-75 mt-0.5">Reception: {card.weddingDetails.receptionTime}</div>
                {card.weddingDetails.dressCode && (
                  <div className="mt-3 pt-2 border-t border-white/10 text-xs">
                    <span className="opacity-60">Dress Code: </span>
                    <span className="font-medium text-amber-300">{card.weddingDetails.dressCode}</span>
                  </div>
                )}
              </div>

              <div
                className="p-4 rounded-2xl border"
                style={{
                  backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
                  borderColor: `${theme.primaryColor}30`,
                }}
              >
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold opacity-70 mb-2">
                  <MapPin className="w-4 h-4 text-rose-400" />
                  Venue Information
                </div>
                <div className="text-sm font-semibold">{card.weddingDetails.venueName}</div>
                <div className="text-xs opacity-75 mt-0.5">{card.weddingDetails.venueAddress}</div>
                {card.weddingDetails.mapsUrl && (
                  <a
                    href={card.weddingDetails.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-rose-400 font-medium mt-2 hover:underline"
                  >
                    View Map Directions <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>

            {/* Our Love Story */}
            {card.weddingDetails.story && (
              <div
                className="p-5 rounded-2xl border text-center"
                style={{
                  backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
                  borderColor: `${theme.primaryColor}20`,
                }}
              >
                <h4 className="text-sm font-serif font-bold italic mb-2 text-rose-300">
                  Our Journey to Forever
                </h4>
                <p className="text-xs leading-relaxed opacity-85">{card.weddingDetails.story}</p>
              </div>
            )}

            {/* Wedding RSVP Form */}
            <div
              className="p-5 rounded-2xl border relative overflow-hidden"
              style={{
                backgroundColor: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.03)',
                borderColor: `${theme.primaryColor}40`,
              }}
            >
              <h3 className="text-base font-bold mb-1 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-rose-400" />
                Kindly RSVP by August 15
              </h3>
              <p className="text-xs opacity-70 mb-4">
                Please let us know if you will celebrate with us in person.
              </p>

              {rsvpSubmitted ? (
                <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-center text-sm font-medium">
                  ✨ Thank you! Your RSVP has been confirmed. We cannot wait to see you!
                </div>
              ) : (
                <form onSubmit={handleRsvpSubmit} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input
                      type="text"
                      placeholder="Your Full Name *"
                      required
                      value={rsvpName}
                      onChange={(e) => setRsvpName(e.target.value)}
                      className="px-3 py-2 text-xs rounded-xl bg-black/30 border border-white/10 focus:border-rose-400 outline-none"
                    />
                    <input
                      type="email"
                      placeholder="Email Address *"
                      required
                      value={rsvpEmail}
                      onChange={(e) => setRsvpEmail(e.target.value)}
                      className="px-3 py-2 text-xs rounded-xl bg-black/30 border border-white/10 focus:border-rose-400 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <select
                      value={rsvpStatus}
                      onChange={(e) => setRsvpStatus(e.target.value as any)}
                      className="px-3 py-2 text-xs rounded-xl bg-black/40 border border-white/10 outline-none"
                    >
                      <option value="attending">Accepts with Joy (Attending)</option>
                      <option value="declined">Declines with Regret</option>
                    </select>

                    <select
                      value={rsvpGuests}
                      onChange={(e) => setRsvpGuests(e.target.value)}
                      className="px-3 py-2 text-xs rounded-xl bg-black/40 border border-white/10 outline-none"
                    >
                      <option value="1">1 Guest</option>
                      <option value="2">2 Guests</option>
                      <option value="3">3 Guests</option>
                      <option value="4">4+ Guests</option>
                    </select>
                  </div>

                  <input
                    type="text"
                    placeholder="Dietary requirements or special wishes (optional)"
                    value={rsvpDiet}
                    onChange={(e) => setRsvpDiet(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-black/30 border border-white/10 outline-none"
                  />

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl text-xs font-semibold text-white shadow-lg transition-transform active:scale-95 cursor-pointer"
                    style={{
                      background: 'linear-gradient(135deg, #e11d48, #be123c)',
                    }}
                  >
                    Confirm RSVP
                  </button>
                </form>
              )}
            </div>
          </div>
        )}

        {/* 2. BIRTHDAY MODULE */}
        {category === 'birthday' && card.birthdayDetails && (
          <div className="space-y-6 my-6">
            <div
              className="p-6 rounded-2xl text-center border relative overflow-hidden"
              style={{
                backgroundColor: `${theme.primaryColor}15`,
                borderColor: `${theme.primaryColor}50`,
              }}
            >
              <div className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-amber-400 text-black mb-3">
                {card.birthdayDetails.turningAge ? `TURNING ${card.birthdayDetails.turningAge}!` : 'BIRTHDAY BASH'}
              </div>
              <h2 className="text-3xl font-extrabold tracking-tight">
                {card.birthdayDetails.honoreeName}
              </h2>
              <p className="text-sm opacity-80 mt-1">{card.birthdayDetails.theme}</p>

              <button
                onClick={triggerConfetti}
                className="mt-4 px-4 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-400 to-rose-400 shadow-lg flex items-center gap-2 mx-auto hover:opacity-90 active:scale-95 cursor-pointer"
              >
                <PartyPopper className="w-4 h-4" />
                Tap for Birthday Confetti!
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-xl border bg-black/20 border-white/10 text-xs">
                <span className="opacity-60 block uppercase text-[10px]">Date & Time</span>
                <span className="font-bold text-sm block mt-1">{card.birthdayDetails.birthDate}</span>
                <span className="opacity-80 block">{card.birthdayDetails.partyTime}</span>
              </div>
              <div className="p-4 rounded-xl border bg-black/20 border-white/10 text-xs">
                <span className="opacity-60 block uppercase text-[10px]">Location</span>
                <span className="font-bold text-sm block mt-1">{card.birthdayDetails.venueName}</span>
                <span className="opacity-80 truncate block">{card.birthdayDetails.venueAddress}</span>
              </div>
            </div>

            {card.birthdayDetails.customMessage && (
              <div className="p-4 rounded-xl border border-white/10 bg-black/20 text-xs leading-relaxed">
                <p className="opacity-90">{card.birthdayDetails.customMessage}</p>
              </div>
            )}
          </div>
        )}

        {/* 3. EVENT / CONFERENCE MODULE */}
        {category === 'event' && card.eventDetails && (
          <div className="space-y-6 my-6">
            <div
              className="p-5 rounded-2xl border"
              style={{
                backgroundColor: `${theme.primaryColor}15`,
                borderColor: `${theme.primaryColor}40`,
              }}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-wider font-semibold opacity-75">
                  Organized by {card.eventDetails.organizer}
                </span>
                {card.eventDetails.ticketInfo?.badge && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {card.eventDetails.ticketInfo.badge}
                  </span>
                )}
              </div>
              <h2 className="text-xl sm:text-2xl font-bold mt-2">
                {card.eventDetails.eventTitle}
              </h2>
              <div className="flex flex-wrap items-center gap-4 mt-3 text-xs opacity-80">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{new Date(card.eventDetails.startDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{card.eventDetails.location}</span>
                </div>
              </div>
            </div>

            {/* Event Schedule Agenda */}
            {card.eventDetails.schedule && card.eventDetails.schedule.length > 0 && (
              <div>
                <h3 className="text-xs uppercase tracking-wider opacity-60 font-semibold mb-3">
                  Event Agenda & Tracks
                </h3>
                <div className="space-y-2.5">
                  {card.eventDetails.schedule.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl border bg-black/20 border-white/10 flex items-start gap-3"
                    >
                      <div
                        className="px-2 py-1 rounded text-[10px] font-mono font-bold shrink-0 mt-0.5"
                        style={{ backgroundColor: `${theme.primaryColor}30`, color: theme.secondaryColor }}
                      >
                        {item.time}
                      </div>
                      <div>
                        <div className="text-xs font-bold">{item.title}</div>
                        {item.speaker && (
                          <div className="text-[11px] opacity-70 mt-0.5">Speaker: {item.speaker}</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Featured Speakers */}
            {card.eventDetails.speakers && card.eventDetails.speakers.length > 0 && (
              <div>
                <h3 className="text-xs uppercase tracking-wider opacity-60 font-semibold mb-3">
                  Keynote Speakers
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {card.eventDetails.speakers.map((spk, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl border bg-black/20 border-white/10 flex items-center gap-3"
                    >
                      <img
                        src={spk.avatarUrl}
                        alt={spk.name}
                        className="w-10 h-10 rounded-full object-cover shrink-0"
                      />
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold truncate">{spk.name}</div>
                        <div className="text-[10px] opacity-70 truncate">{spk.role}</div>
                        <div className="text-[9px] opacity-50 truncate">{spk.company}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* 4. RESTAURANT DIGITAL MENU MODULE */}
        {category === 'restaurant' && card.menuItems && card.menuItems.length > 0 && (
          <div className="space-y-6 my-6">
            {/* Category Filter Tabs */}
            {card.menuCategories && card.menuCategories.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                <button
                  onClick={() => setActiveMenuCat('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium shrink-0 transition-all cursor-pointer ${
                    activeMenuCat === 'all'
                      ? 'bg-amber-500 text-black font-bold shadow-md'
                      : 'bg-black/20 border border-white/10 opacity-70 hover:opacity-100'
                  }`}
                >
                  All Items
                </button>
                {card.menuCategories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveMenuCat(cat.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium shrink-0 transition-all cursor-pointer ${
                      activeMenuCat === cat.id
                        ? 'bg-amber-500 text-black font-bold shadow-md'
                        : 'bg-black/20 border border-white/10 opacity-70 hover:opacity-100'
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            )}

            {/* Menu Items List */}
            <div className="space-y-3">
              {card.menuItems
                .filter((item) => activeMenuCat === 'all' || item.categoryId === activeMenuCat)
                .map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-2xl border flex items-start justify-between gap-3 bg-black/20 border-white/10 transition-all hover:border-amber-500/40"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-amber-200">{item.name}</span>
                        {item.tags?.includes('chef_special') && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                            Chef Special
                          </span>
                        )}
                        {item.tags?.includes('spicy') && (
                          <span className="text-xs" title="Spicy">🌶️</span>
                        )}
                        {item.tags?.includes('vegetarian') && (
                          <span className="text-[10px] px-1 bg-green-900/40 text-green-300 rounded border border-green-700/40">V</span>
                        )}
                      </div>
                      <p className="text-xs opacity-75 mt-1 leading-relaxed">{item.description}</p>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-sm font-bold text-amber-400 font-mono">
                        {item.currency}{item.price.toFixed(2)}
                      </div>
                      <button
                        onClick={() => {
                          if (onOpenBooking) onOpenBooking();
                        }}
                        className="mt-2 text-[10px] px-2 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30 cursor-pointer"
                      >
                        Reserve Table
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* 5. BUSINESS SERVICES MODULE */}
        {category === 'business' && card.services && card.services.length > 0 && (
          <div className="mb-6">
            <h4 className="text-xs uppercase tracking-wider opacity-60 font-semibold mb-3">
              Services & Specialties
            </h4>
            <div className="space-y-2.5">
              {card.services.map((svc) => (
                <div
                  key={svc.id}
                  className="p-3.5 rounded-xl border flex items-center justify-between gap-3 bg-black/20 border-white/10"
                >
                  <div>
                    <div className="text-xs font-bold">{svc.title}</div>
                    <div className="text-[11px] opacity-75 mt-0.5">{svc.description}</div>
                  </div>
                  {svc.price && (
                    <div
                      className="px-2 py-1 rounded text-xs font-semibold shrink-0"
                      style={{ backgroundColor: `${theme.primaryColor}20`, color: theme.secondaryColor }}
                    >
                      {svc.price}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Primary Interactive CTA Buttons */}
        <div className="space-y-2.5 mt-6">
          {onOpenBooking && (
            <button
              onClick={onOpenBooking}
              className="w-full py-3.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-xl transition-all duration-200 cursor-pointer hover:opacity-90 active:scale-98"
              style={{
                background: `linear-gradient(135deg, ${theme.primaryColor}, ${theme.secondaryColor})`,
                color: '#ffffff',
              }}
            >
              <Calendar className="w-4 h-4" />
              {category === 'restaurant'
                ? 'Reserve a Dining Table'
                : category === 'wedding'
                ? 'View Wedding Registry & Itinerary'
                : 'Schedule a Meeting / Consultation'}
            </button>
          )}

          {onOpenNfc && (
            <button
              onClick={onOpenNfc}
              className="w-full py-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 border transition-all cursor-pointer hover:bg-white/5 active:scale-98"
              style={{
                borderColor: `${theme.primaryColor}40`,
                color: theme.textColor,
              }}
            >
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              Write This Card to Physical NFC Tag
            </button>
          )}
        </div>

        {/* Quick Message / Enquiry Form on Card */}
        <div
          className="mt-8 p-5 rounded-2xl border"
          style={{
            backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.02)',
            borderColor: `${theme.primaryColor}25`,
          }}
        >
          <h4 className="text-sm font-bold mb-1 flex items-center gap-1.5">
            <Send className="w-3.5 h-3.5" style={{ color: theme.primaryColor }} />
            Send a Direct Message
          </h4>
          <p className="text-xs opacity-65 mb-3">
            Your message will be sent directly to the card owner.
          </p>

          {enqSent ? (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs text-center font-medium">
              ✓ Message delivered! The owner will get in touch soon.
            </div>
          ) : (
            <form onSubmit={handleEnquirySubmit} className="space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Your Name *"
                  required
                  value={enqName}
                  onChange={(e) => setEnqName(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl bg-black/30 border border-white/10 outline-none focus:border-cyan-400"
                />
                <input
                  type="email"
                  placeholder="Your Email *"
                  required
                  value={enqEmail}
                  onChange={(e) => setEnqEmail(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl bg-black/30 border border-white/10 outline-none focus:border-cyan-400"
                />
              </div>
              <textarea
                placeholder="Write your note or inquiry here..."
                required
                rows={2}
                value={enqMessage}
                onChange={(e) => setEnqMessage(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-black/30 border border-white/10 outline-none focus:border-cyan-400 resize-none"
              />
              <button
                type="submit"
                className="w-full py-2 rounded-xl text-xs font-semibold text-white transition-opacity hover:opacity-90 cursor-pointer"
                style={{
                  backgroundColor: theme.primaryColor,
                }}
              >
                Send Message
              </button>
            </form>
          )}
        </div>

        {/* Footer Brand Seal */}
        <div className="mt-8 text-center pt-6 border-t border-white/10">
          <div className="text-[11px] font-semibold tracking-wider uppercase opacity-75">
            POWERED BY <span className="text-cyan-400 font-bold">ZETACARD</span>
          </div>
          <div className="text-[10px] opacity-50 mt-0.5">
            Founder & Creator: Shahid Tufail • Independent Digital Card Ecosystem
          </div>
        </div>
      </div>
    </div>
  );
};
