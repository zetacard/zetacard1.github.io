import React, { useState } from 'react';
import { Card, Booking } from '../../types';
import { dbService } from '../../services/db';
import {
  X,
  Calendar,
  Clock,
  User,
  Mail,
  Phone,
  FileText,
  CheckCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface BookingModalProps {
  card: Card;
  isOpen: boolean;
  onClose: () => void;
}

const AVAILABLE_SLOTS = [
  '09:00 AM - 09:45 AM',
  '10:30 AM - 11:15 AM',
  '01:00 PM - 01:45 PM',
  '02:30 PM - 03:15 PM',
  '04:00 PM - 04:45 PM',
  '06:00 PM - 07:00 PM',
  '07:30 PM - 09:00 PM',
];

export const BookingModal: React.FC<BookingModalProps> = ({ card, isOpen, onClose }) => {
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [selectedSlot, setSelectedSlot] = useState<string>(AVAILABLE_SLOTS[1]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [submittedBooking, setSubmittedBooking] = useState<Booking | null>(null);

  if (!isOpen) return null;

  // Check if slot is taken
  const existingBookings = dbService.getBookings(card.userId);
  const isSlotTaken = (slot: string) => {
    return existingBookings.some(
      (b) => b.cardId === card.id && b.date === selectedDate && b.timeSlot === slot && b.status !== 'cancelled'
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !selectedDate || !selectedSlot) return;

    if (isSlotTaken(selectedSlot)) {
      alert('This slot is already reserved. Please choose another time slot.');
      return;
    }

    const newBooking = dbService.createBooking({
      cardId: card.id,
      cardTitle: card.title,
      ownerId: card.userId,
      clientName: name,
      clientEmail: email,
      clientPhone: phone,
      date: selectedDate,
      timeSlot: selectedSlot,
      status: 'pending',
      notes,
    });

    // Auto-create Contact in CRM
    dbService.createContact({
      ownerId: card.userId,
      sourceCardId: card.id,
      name,
      email,
      phone,
      company: '',
      role: 'Client / Booking',
      tags: ['Booking Lead', card.category],
      notes: `Booked: ${selectedDate} at ${selectedSlot} (${notes || 'No extra notes'})`,
      status: 'new',
    });

    setSubmittedBooking(newBooking);
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl text-slate-100 my-8">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {submittedBooking ? (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold tracking-tight text-emerald-300">
              Booking Request Received!
            </h3>
            <p className="text-xs text-slate-300 mt-2 max-w-sm mx-auto leading-relaxed">
              Your request for <span className="font-semibold text-white">{card.title}</span> has been sent. A confirmation has been logged with ID #{submittedBooking.id.slice(-6).toUpperCase()}.
            </p>

            <div className="mt-5 p-4 rounded-2xl bg-slate-950 border border-slate-800 text-left text-xs space-y-1.5 max-w-xs mx-auto">
              <div className="flex justify-between">
                <span className="text-slate-400">Date:</span>
                <span className="font-bold text-white">{submittedBooking.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Time:</span>
                <span className="font-bold text-cyan-400">{submittedBooking.timeSlot}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Client:</span>
                <span className="font-medium text-white">{submittedBooking.clientName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Status:</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                  {submittedBooking.status.toUpperCase()}
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="mt-6 px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-xs transition-all cursor-pointer"
            >
              Done
            </button>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold tracking-tight">
                  {card.category === 'restaurant' ? 'Reserve a Table' : 'Book an Appointment'}
                </h3>
                <p className="text-xs text-slate-400">
                  Scheduling with <span className="text-cyan-400 font-semibold">{card.title}</span>
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Date Selection */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  Select Date
                </label>
                <input
                  type="date"
                  required
                  min={new Date().toISOString().split('T')[0]}
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-medium text-slate-100 outline-none focus:border-cyan-500"
                />
              </div>

              {/* Time Slots */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  Available Time Slots
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
                  {AVAILABLE_SLOTS.map((slot) => {
                    const taken = isSlotTaken(slot);
                    return (
                      <button
                        type="button"
                        key={slot}
                        disabled={taken}
                        onClick={() => setSelectedSlot(slot)}
                        className={`p-2 rounded-xl text-[11px] font-medium border text-center transition-all cursor-pointer ${
                          taken
                            ? 'bg-slate-950/40 border-slate-800 text-slate-600 cursor-not-allowed line-through'
                            : selectedSlot === slot
                            ? 'bg-cyan-500 text-black font-bold border-cyan-400 shadow-md'
                            : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                        }`}
                      >
                        {slot} {taken && '(Booked)'}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Client Contact Info */}
              <div className="space-y-2.5 pt-2 border-t border-slate-800">
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="Jane Doe"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="jane@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Phone Number (optional)</label>
                  <input
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Meeting Notes / Special Requests</label>
                  <textarea
                    rows={2}
                    placeholder="Provide context or agenda topics..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 outline-none focus:border-cyan-500 resize-none"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-lg transition-transform active:scale-98 cursor-pointer mt-2"
              >
                Confirm Appointment Request
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
