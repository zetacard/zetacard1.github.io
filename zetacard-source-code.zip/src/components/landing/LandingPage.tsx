import React from 'react';
import { CardCategory } from '../../types';
import {
  Sparkles,
  ArrowRight,
  Shield,
  Radio,
  QrCode,
  Smartphone,
  Calendar,
  Utensils,
  Heart,
  PartyPopper,
  Briefcase,
  CheckCircle2,
  Award,
  Globe,
  Database,
  Zap,
} from 'lucide-react';

interface LandingPageProps {
  onExploreTemplates: (category?: CardCategory) => void;
  onOpenDashboard: () => void;
  onOpenCardBySlug: (slug: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onExploreTemplates,
  onOpenDashboard,
  onOpenCardBySlug,
}) => {
  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-24 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        {/* Background glow orbs */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-cyan-500/20 via-indigo-500/20 to-purple-500/20 blur-[120px] rounded-full pointer-events-none -z-10" />

        {/* Founder Tag & Version */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-slate-900 border border-slate-800 text-slate-300 shadow-xl mb-6">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>Founded & Architected by</span>
          <span className="text-cyan-400 font-bold">Shahid Tufail</span>
          <span className="text-slate-600">|</span>
          <span className="text-amber-400">Independent Ecosystem</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.1] max-w-4xl mx-auto">
          The All-in-One <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-400 bg-clip-text text-transparent">Digital Card</span> & Productivity Platform
        </h1>

        <p className="mt-6 text-base sm:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Create exquisite digital business cards, romantic wedding invitations, milestone birthday cards, conference agendas, and interactive restaurant menus—complete with QR codes, NFC hardware programming, and Gemini AI.
        </p>

        {/* Hero CTAs */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => onExploreTemplates()}
            className="px-7 py-4 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-extrabold text-sm sm:text-base flex items-center gap-2.5 shadow-2xl shadow-cyan-500/25 transition-transform active:scale-95 cursor-pointer"
          >
            <span>Explore 100+ Templates</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => onOpenCardBySlug('shahid-tufail')}
            className="px-6 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-semibold text-sm sm:text-base flex items-center gap-2 transition-all cursor-pointer"
          >
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span>Test Live Founder Card</span>
          </button>

          <button
            onClick={onOpenDashboard}
            className="px-6 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-semibold text-sm sm:text-base transition-all cursor-pointer"
          >
            Go to Dashboard
          </button>
        </div>

        {/* Key Pillars */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <Radio className="w-5 h-5 text-cyan-400 mb-2" />
            <div className="text-xs font-bold text-white">Physical NFC Writing</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Program any smart card via Web NFC</div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <QrCode className="w-5 h-5 text-purple-400 mb-2" />
            <div className="text-xs font-bold text-white">Dynamic QR System</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Update cards without changing QR</div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <Sparkles className="w-5 h-5 text-amber-400 mb-2" />
            <div className="text-xs font-bold text-white">Gemini 3.8 AI Copilot</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Server-side copywriting assistant</div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <Database className="w-5 h-5 text-emerald-400 mb-2" />
            <div className="text-xs font-bold text-white">100% Data Ownership</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Zero lock-in with JSON export & restore</div>
          </div>
        </div>
      </section>

      {/* 5 Core Disciplines Showcase */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-900">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl font-extrabold text-white">Five Complete Ecosystem Modules</h2>
          <p className="text-sm text-slate-400 mt-2">
            Engineered with dedicated feature sets for modern entrepreneurs, lovers, party hosts, and restaurants.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Module 1: Business Cards */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-4">
              <Briefcase className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Digital Business & Visiting Cards</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Replace paper business cards forever. One-tap vCard address book saving, interactive appointment booking, custom branding, and social links.
            </p>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-cyan-400 font-semibold">20+ Executive Templates</span>
              <button
                onClick={() => onExploreTemplates('business')}
                className="text-white hover:text-cyan-400 font-bold flex items-center gap-1 cursor-pointer"
              >
                Explore <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Module 2: Wedding Invitations */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-rose-500/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center mb-4">
              <Heart className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Luxury Wedding Invitations</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Celebrate your love story with animated countdown timers, live RSVP collection, venue map integration, gift registry links, and dress code notes.
            </p>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-rose-400 font-semibold">20+ Romance Templates</span>
              <button
                onClick={() => onExploreTemplates('wedding')}
                className="text-white hover:text-rose-400 font-bold flex items-center gap-1 cursor-pointer"
              >
                Explore <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Module 3: Birthday Cards */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-4">
              <PartyPopper className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Birthday & Milestone Celebrations</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Interactive party invites with celebratory confetti triggers, milestone age badges, guest attendance forms, and theme dress styling.
            </p>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-amber-400 font-semibold">20+ Party Templates</span>
              <button
                onClick={() => onExploreTemplates('birthday')}
                className="text-white hover:text-amber-400 font-bold flex items-center gap-1 cursor-pointer"
              >
                Explore <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Module 4: Event & Conferences */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mb-4">
              <Calendar className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Conferences, Summits & Galas</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Multi-track agendas, speaker profile cards, ticket registration links, virtual stream buttons, and venue navigation for corporate events.
            </p>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-indigo-400 font-semibold">20+ Summit Templates</span>
              <button
                onClick={() => onExploreTemplates('event')}
                className="text-white hover:text-indigo-400 font-bold flex items-center gap-1 cursor-pointer"
              >
                Explore <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Module 5: Restaurant Menus */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-4">
              <Utensils className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Restaurant Digital QR Menus</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Touchless tabletop QR menus with dietary tags (vegan, gluten-free, spicy), categorized courses, appetizing images, and table booking.
            </p>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-emerald-400 font-semibold">20+ Culinary Templates</span>
              <button
                onClick={() => onExploreTemplates('restaurant')}
                className="text-white hover:text-emerald-400 font-bold flex items-center gap-1 cursor-pointer"
              >
                Explore <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Module 6: Productivity CRM */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950/60 to-purple-950/60 border border-indigo-500/30">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-300 flex items-center justify-center mb-4">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white">Integrated Business Productivity</h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Every client message, booking request, or RSVP attendee automatically syncs into your personal ZetaCard CRM and Daily Tasks planner.
            </p>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-purple-300 font-semibold">Full CRM Suite Included</span>
              <button
                onClick={onOpenDashboard}
                className="text-cyan-400 font-bold flex items-center gap-1 cursor-pointer"
              >
                Open Dashboard <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Founder's Mission Statement */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="p-8 sm:p-12 rounded-3xl bg-slate-900 border border-slate-800 text-center relative overflow-hidden">
          <div className="w-16 h-16 rounded-full bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 flex items-center justify-center mx-auto mb-4">
            <Award className="w-8 h-8" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Built for Independence, Owned by You
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto mt-4 leading-relaxed italic">
            "ZetaCard is built on the philosophy that your professional identity, your events, and your customer relationships should never be locked inside closed proprietary silos. With complete source ownership, persistent client-side databases, and native NFC support, ZetaCard gives you total freedom."
          </p>
          <div className="mt-5 font-bold text-sm text-cyan-400">
            Shahid Tufail
          </div>
          <div className="text-[11px] text-slate-500">
            Founder & Principal Architect, ZetaCard
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-xs text-slate-500">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="font-extrabold text-white text-sm">ZETACARD</span>
            <span className="ml-2">© 2026. All rights reserved.</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="https://zeta-card.base44.app/" target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400">
              Reference Platform
            </a>
            <span>•</span>
            <button onClick={onOpenDashboard} className="hover:text-cyan-400 cursor-pointer">
              Dashboard
            </button>
            <span>•</span>
            <span>Created by Shahid Tufail</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
