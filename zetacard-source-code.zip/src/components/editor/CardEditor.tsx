import React, { useState } from 'react';
import { Card, SocialLink, BusinessService, MenuItem, MenuCategory } from '../../types';
import { CardMockup } from '../cards/CardMockup';
import { AICopilotModal } from '../ai/AICopilotModal';
import { QRModal } from '../qr/QRModal';
import { NFCModal } from '../qr/NFCModal';
import { dbService } from '../../services/db';
import {
  Save,
  Globe,
  Palette,
  Layout,
  Layers,
  Sparkles,
  Share2,
  Radio,
  ArrowLeft,
  Plus,
  Trash2,
  CheckCircle,
  Eye,
  Utensils,
  Calendar,
  Heart,
  PartyPopper,
  Briefcase,
  HelpCircle,
} from 'lucide-react';

interface CardEditorProps {
  initialCard: Card;
  onBack: () => void;
  onSaved: (card: Card) => void;
}

export const CardEditor: React.FC<CardEditorProps> = ({
  initialCard,
  onBack,
  onSaved,
}) => {
  const [card, setCard] = useState<Card>({ ...initialCard });
  const [activeTab, setActiveTab] = useState<'content' | 'category' | 'style' | 'social'>('content');
  const [showAiModal, setShowAiModal] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showNfcModal, setShowNfcModal] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Field updater
  const updateField = <K extends keyof Card>(field: K, val: Card[K]) => {
    setCard((prev) => ({
      ...prev,
      [field]: val,
      updatedAt: new Date().toISOString(),
    }));
  };

  const updateTheme = (key: keyof Card['theme'], val: string) => {
    setCard((prev) => ({
      ...prev,
      theme: {
        ...prev.theme,
        [key]: val,
      },
      updatedAt: new Date().toISOString(),
    }));
  };

  const handleSave = (publish: boolean = false) => {
    const updatedCard: Card = {
      ...card,
      status: publish ? 'published' : card.status,
      updatedAt: new Date().toISOString(),
    };
    dbService.saveCard(updatedCard);
    setCard(updatedCard);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
    onSaved(updatedCard);
  };

  // Social Links management
  const addSocialLink = () => {
    const newLink: SocialLink = {
      id: `soc-${Date.now()}`,
      platform: 'linkedin',
      url: 'https://',
      label: 'LinkedIn',
    };
    updateField('socialLinks', [...(card.socialLinks || []), newLink]);
  };

  const removeSocialLink = (id: string) => {
    updateField('socialLinks', (card.socialLinks || []).filter((s) => s.id !== id));
  };

  const updateSocialLink = (id: string, updates: Partial<SocialLink>) => {
    updateField(
      'socialLinks',
      (card.socialLinks || []).map((s) => (s.id === id ? { ...s, ...updates } : s))
    );
  };

  // Business Services management
  const addService = () => {
    const newSvc: BusinessService = {
      id: `svc-${Date.now()}`,
      title: 'New Service',
      description: 'Describe what you deliver...',
      price: '$100',
    };
    updateField('services', [...(card.services || []), newSvc]);
  };

  const removeService = (id: string) => {
    updateField('services', (card.services || []).filter((s) => s.id !== id));
  };

  // Restaurant Menu items management
  const addMenuItem = () => {
    const newItem: MenuItem = {
      id: `item-${Date.now()}`,
      categoryId: card.menuCategories?.[0]?.id || 'cat-mains',
      name: 'Chef Special Plate',
      description: 'Artisan ingredients cooked to perfection.',
      price: 24,
      currency: '$',
      tags: ['chef_special'],
      isAvailable: true,
    };
    updateField('menuItems', [...(card.menuItems || []), newItem]);
  };

  const removeMenuItem = (id: string) => {
    updateField('menuItems', (card.menuItems || []).filter((m) => m.id !== id));
  };

  const updateMenuItem = (id: string, updates: Partial<MenuItem>) => {
    updateField(
      'menuItems',
      (card.menuItems || []).map((m) => (m.id === id ? { ...m, ...updates } : m))
    );
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Editor Navbar */}
      <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
            title="Return to Dashboard"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold tracking-tight truncate max-w-xs sm:max-w-md">
                {card.title || 'Untitled Card'}
              </h2>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                  card.status === 'published'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                }`}
              >
                {card.status}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              zetacard.app/?card={card.slug}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* AI Copilot Button */}
          <button
            onClick={() => setShowAiModal(true)}
            className="px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">AI Copilot</span>
          </button>

          {/* Share & QR */}
          <button
            onClick={() => setShowQrModal(true)}
            className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            title="Share & QR Code"
          >
            <Share2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">QR Code</span>
          </button>

          {/* Save Draft */}
          <button
            onClick={() => handleSave(false)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold transition-all cursor-pointer"
          >
            Save Draft
          </button>

          {/* Publish Button */}
          <button
            onClick={() => handleSave(true)}
            className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-lg transition-transform active:scale-95 cursor-pointer flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            Publish Card
          </button>
        </div>
      </header>

      {/* Save Success Alert Banner */}
      {savedSuccess && (
        <div className="bg-emerald-950/80 border-b border-emerald-500/40 px-4 py-2 text-center text-xs text-emerald-300 flex items-center justify-center gap-1.5 animate-fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          Card changes saved successfully! Live preview updated.
        </div>
      )}

      {/* Main Split Layout: Left Form, Right Mockup Preview */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Side: Editor Form Tabs */}
        <div className="lg:col-span-7 xl:col-span-7 border-r border-slate-800/80 flex flex-col h-full bg-slate-950 overflow-y-auto">
          {/* Editor Sub-Navigation Tabs */}
          <div className="flex items-center gap-1 p-2 bg-slate-900/60 border-b border-slate-800/80 sticky top-0 z-20">
            {[
              { id: 'content', label: 'Basic Content', icon: Layout },
              { id: 'category', label: `${card.category.toUpperCase()} Details`, icon: Layers },
              { id: 'social', label: 'Links & Services', icon: Globe },
              { id: 'style', label: 'Theme & Style', icon: Palette },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="p-5 sm:p-7 space-y-6 max-w-2xl">
            {/* TAB 1: BASIC CONTENT */}
            {activeTab === 'content' && (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">
                    Card Title / Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={card.title}
                    onChange={(e) => updateField('title', e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm font-semibold text-white outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Subtitle / Headline
                    </label>
                    <input
                      type="text"
                      value={card.subtitle || ''}
                      onChange={(e) => updateField('subtitle', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Company / Organization
                    </label>
                    <input
                      type="text"
                      value={card.company || ''}
                      onChange={(e) => updateField('company', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>

                {/* Bio / Description with AI Assist trigger */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-300">
                      About / Narrative Description
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowAiModal(true)}
                      className="text-[11px] text-purple-400 hover:text-purple-300 flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3" />
                      Refine with AI
                    </button>
                  </div>
                  <textarea
                    rows={4}
                    value={card.bio}
                    onChange={(e) => updateField('bio', e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 outline-none focus:border-cyan-500 leading-relaxed"
                  />
                </div>

                {/* Photos & Images */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Profile / Avatar Photo URL
                    </label>
                    <input
                      type="url"
                      value={card.profileImageUrl}
                      onChange={(e) => updateField('profileImageUrl', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 outline-none focus:border-cyan-500 truncate"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Cover Banner Image URL
                    </label>
                    <input
                      type="url"
                      value={card.coverImageUrl}
                      onChange={(e) => updateField('coverImageUrl', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 outline-none focus:border-cyan-500 truncate"
                    />
                  </div>
                </div>

                {/* Contact Points */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Direct Phone Number
                    </label>
                    <input
                      type="tel"
                      value={card.phone || ''}
                      onChange={(e) => updateField('phone', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Public Email Address
                    </label>
                    <input
                      type="email"
                      value={card.email || ''}
                      onChange={(e) => updateField('email', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Website URL
                    </label>
                    <input
                      type="url"
                      value={card.website || ''}
                      onChange={(e) => updateField('website', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-400 block mb-1">
                      Physical Address
                    </label>
                    <input
                      type="text"
                      value={card.address || ''}
                      onChange={(e) => updateField('address', e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 outline-none"
                    />
                  </div>
                </div>

                {/* Slug & NFC config */}
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Permanent URL Slug
                    </label>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500 font-mono">.../?card=</span>
                      <input
                        type="text"
                        value={card.slug}
                        onChange={(e) => updateField('slug', e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                        className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-300 outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <div className="text-xs font-semibold text-slate-200">Enable NFC Tag Support</div>
                      <div className="text-[11px] text-slate-500">Allow instant tap programming to smart cards</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={card.nfcEnabled}
                      onChange={(e) => updateField('nfcEnabled', e.target.checked)}
                      className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: CATEGORY SPECIFIC FIELDS */}
            {activeTab === 'category' && (
              <div className="space-y-5">
                {/* WEDDING DETAILS */}
                {card.category === 'wedding' && (
                  <div className="space-y-4">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-rose-400 flex items-center gap-1.5">
                      <Heart className="w-4 h-4" /> Wedding Couple & Ceremony Details
                    </h3>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Bride Full Name</label>
                        <input
                          type="text"
                          value={card.weddingDetails?.brideName || ''}
                          onChange={(e) =>
                            updateField('weddingDetails', {
                              ...card.weddingDetails!,
                              brideName: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Groom Full Name</label>
                        <input
                          type="text"
                          value={card.weddingDetails?.groomName || ''}
                          onChange={(e) =>
                            updateField('weddingDetails', {
                              ...card.weddingDetails!,
                              groomName: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Wedding Date</label>
                        <input
                          type="datetime-local"
                          value={card.weddingDetails?.weddingDate ? card.weddingDetails.weddingDate.substring(0, 16) : ''}
                          onChange={(e) =>
                            updateField('weddingDetails', {
                              ...card.weddingDetails!,
                              weddingDate: new Date(e.target.value).toISOString(),
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Ceremony Time</label>
                        <input
                          type="text"
                          value={card.weddingDetails?.ceremonyTime || ''}
                          onChange={(e) =>
                            updateField('weddingDetails', {
                              ...card.weddingDetails!,
                              ceremonyTime: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Reception Time</label>
                        <input
                          type="text"
                          value={card.weddingDetails?.receptionTime || ''}
                          onChange={(e) =>
                            updateField('weddingDetails', {
                              ...card.weddingDetails!,
                              receptionTime: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Venue Name</label>
                        <input
                          type="text"
                          value={card.weddingDetails?.venueName || ''}
                          onChange={(e) =>
                            updateField('weddingDetails', {
                              ...card.weddingDetails!,
                              venueName: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Dress Code</label>
                        <input
                          type="text"
                          value={card.weddingDetails?.dressCode || ''}
                          onChange={(e) =>
                            updateField('weddingDetails', {
                              ...card.weddingDetails!,
                              dressCode: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* BIRTHDAY DETAILS */}
                {card.category === 'birthday' && (
                  <div className="space-y-4">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-amber-400 flex items-center gap-1.5">
                      <PartyPopper className="w-4 h-4" /> Birthday Party Details
                    </h3>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Honoree Name</label>
                        <input
                          type="text"
                          value={card.birthdayDetails?.honoreeName || ''}
                          onChange={(e) =>
                            updateField('birthdayDetails', {
                              ...card.birthdayDetails!,
                              honoreeName: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Turning Age (optional)</label>
                        <input
                          type="number"
                          value={card.birthdayDetails?.turningAge || ''}
                          onChange={(e) =>
                            updateField('birthdayDetails', {
                              ...card.birthdayDetails!,
                              turningAge: parseInt(e.target.value) || undefined,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Birth Date</label>
                        <input
                          type="date"
                          value={card.birthdayDetails?.birthDate || ''}
                          onChange={(e) =>
                            updateField('birthdayDetails', {
                              ...card.birthdayDetails!,
                              birthDate: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Party Hours / Time</label>
                        <input
                          type="text"
                          value={card.birthdayDetails?.partyTime || ''}
                          onChange={(e) =>
                            updateField('birthdayDetails', {
                              ...card.birthdayDetails!,
                              partyTime: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* RESTAURANT MENU ITEMS */}
                {card.category === 'restaurant' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs uppercase tracking-wider font-bold text-amber-300 flex items-center gap-1.5">
                        <Utensils className="w-4 h-4" /> Menu Items ({card.menuItems?.length || 0})
                      </h3>
                      <button
                        type="button"
                        onClick={addMenuItem}
                        className="px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> Add Menu Item
                      </button>
                    </div>

                    <div className="space-y-3">
                      {(card.menuItems || []).map((item) => (
                        <div key={item.id} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <input
                              type="text"
                              value={item.name}
                              onChange={(e) => updateMenuItem(item.id, { name: e.target.value })}
                              placeholder="Dish Name"
                              className="font-bold text-xs bg-transparent border-b border-slate-700 pb-0.5 outline-none text-amber-200 flex-1"
                            />
                            <div className="flex items-center gap-1">
                              <span className="text-xs text-slate-400 font-mono">{item.currency}</span>
                              <input
                                type="number"
                                step="0.5"
                                value={item.price}
                                onChange={(e) => updateMenuItem(item.id, { price: parseFloat(e.target.value) || 0 })}
                                className="w-16 px-1.5 py-0.5 rounded bg-slate-950 text-xs text-right font-mono"
                              />
                              <button
                                type="button"
                                onClick={() => removeMenuItem(item.id)}
                                className="p-1 text-slate-500 hover:text-rose-400 cursor-pointer ml-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                          <input
                            type="text"
                            value={item.description}
                            onChange={(e) => updateMenuItem(item.id, { description: e.target.value })}
                            placeholder="Delectable culinary description..."
                            className="w-full text-[11px] text-slate-300 bg-transparent outline-none"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* BUSINESS / EVENT SERVICES */}
                {(card.category === 'business' || card.category === 'event') && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs uppercase tracking-wider font-bold text-cyan-400 flex items-center gap-1.5">
                        <Briefcase className="w-4 h-4" /> Services & Packages
                      </h3>
                      <button
                        type="button"
                        onClick={addService}
                        className="px-3 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" /> Add Service
                      </button>
                    </div>

                    <div className="space-y-2.5">
                      {(card.services || []).map((svc) => (
                        <div key={svc.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
                          <div className="flex-1 space-y-1">
                            <input
                              type="text"
                              value={svc.title}
                              onChange={(e) => {
                                updateField(
                                  'services',
                                  (card.services || []).map((s) => (s.id === svc.id ? { ...s, title: e.target.value } : s))
                                );
                              }}
                              className="text-xs font-bold bg-transparent text-white w-full outline-none"
                            />
                            <input
                              type="text"
                              value={svc.description}
                              onChange={(e) => {
                                updateField(
                                  'services',
                                  (card.services || []).map((s) => (s.id === svc.id ? { ...s, description: e.target.value } : s))
                                );
                              }}
                              className="text-[11px] text-slate-400 bg-transparent w-full outline-none"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={svc.price || ''}
                              onChange={(e) => {
                                updateField(
                                  'services',
                                  (card.services || []).map((s) => (s.id === svc.id ? { ...s, price: e.target.value } : s))
                                );
                              }}
                              placeholder="$150"
                              className="w-20 px-2 py-1 rounded text-xs text-right bg-slate-950 text-cyan-400 font-mono"
                            />
                            <button
                              type="button"
                              onClick={() => removeService(svc.id)}
                              className="text-slate-500 hover:text-rose-400 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: SOCIAL LINKS */}
            {activeTab === 'social' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs uppercase tracking-wider font-bold text-slate-300">
                    Social Handles & Channels ({card.socialLinks?.length || 0})
                  </h3>
                  <button
                    type="button"
                    onClick={addSocialLink}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Social Handle
                  </button>
                </div>

                <div className="space-y-3">
                  {(card.socialLinks || []).map((link) => (
                    <div key={link.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2.5">
                      <select
                        value={link.platform}
                        onChange={(e) => updateSocialLink(link.id, { platform: e.target.value as any })}
                        className="px-2 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 outline-none"
                      >
                        <option value="linkedin">LinkedIn</option>
                        <option value="twitter">X / Twitter</option>
                        <option value="instagram">Instagram</option>
                        <option value="github">GitHub</option>
                        <option value="youtube">YouTube</option>
                        <option value="whatsapp">WhatsApp</option>
                        <option value="website">Website</option>
                      </select>

                      <input
                        type="url"
                        value={link.url}
                        onChange={(e) => updateSocialLink(link.id, { url: e.target.value })}
                        placeholder="https://..."
                        className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 outline-none"
                      />

                      <button
                        type="button"
                        onClick={() => removeSocialLink(link.id)}
                        className="p-1.5 text-slate-500 hover:text-rose-400 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: THEME & STYLE */}
            {activeTab === 'style' && (
              <div className="space-y-5">
                {/* Font Selection */}
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-2">
                    Card Typography & Font Family
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { name: 'Inter', desc: 'Modern & Clean' },
                      { name: 'Space Grotesk', desc: 'Tech & Futuristic' },
                      { name: 'Outfit', desc: 'Contemporary Luxury' },
                      { name: 'Playfair Display', desc: 'Classic Editorial Serif' },
                      { name: 'Cinzel', desc: 'Regal Baroque Roman' },
                      { name: 'Great Vibes', desc: 'Romance Calligraphy' },
                    ].map((f) => (
                      <button
                        key={f.name}
                        type="button"
                        onClick={() => updateTheme('fontFamily', f.name)}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          card.theme.fontFamily === f.name
                            ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-md'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        <div className="text-sm font-semibold">{f.name}</div>
                        <div className="text-[10px] opacity-70">{f.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color Palette */}
                <div className="pt-2 border-t border-slate-800">
                  <label className="text-xs font-bold text-slate-300 block mb-2">
                    Color Schemes & Accents
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Primary Color</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={card.theme.primaryColor}
                          onChange={(e) => updateTheme('primaryColor', e.target.value)}
                          className="w-8 h-8 rounded border-none cursor-pointer"
                        />
                        <span className="text-xs font-mono">{card.theme.primaryColor}</span>
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Secondary Color</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={card.theme.secondaryColor}
                          onChange={(e) => updateTheme('secondaryColor', e.target.value)}
                          className="w-8 h-8 rounded border-none cursor-pointer"
                        />
                        <span className="text-xs font-mono">{card.theme.secondaryColor}</span>
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Background Color</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={card.theme.backgroundColor}
                          onChange={(e) => updateTheme('backgroundColor', e.target.value)}
                          className="w-8 h-8 rounded border-none cursor-pointer"
                        />
                        <span className="text-xs font-mono">{card.theme.backgroundColor}</span>
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-1">Text Color</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={card.theme.textColor}
                          onChange={(e) => updateTheme('textColor', e.target.value)}
                          className="w-8 h-8 rounded border-none cursor-pointer"
                        />
                        <span className="text-xs font-mono">{card.theme.textColor}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Aesthetic Style */}
                <div className="pt-2 border-t border-slate-800">
                  <label className="text-xs font-bold text-slate-300 block mb-2">
                    Aesthetic Archetype
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {['glass', 'luxury', 'cyber', 'minimal', 'brutalist', 'neon', 'artisan', 'nature'].map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => updateTheme('cardStyle', st)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-medium capitalize border transition-all cursor-pointer ${
                          card.theme.cardStyle === st
                            ? 'bg-cyan-500 text-black font-bold border-cyan-400'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Live Mockup Preview */}
        <div className="lg:col-span-5 xl:col-span-5 p-4 sm:p-8 flex flex-col items-center justify-start bg-slate-900/30 overflow-y-auto">
          <div className="w-full max-w-sm mb-3 flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold flex items-center gap-1.5 text-cyan-400">
              <Eye className="w-3.5 h-3.5" /> Live Preview
            </span>
            <span className="text-[11px] opacity-75">Updates instantly</span>
          </div>
          <CardMockup
            card={card}
            onOpenShare={() => setShowQrModal(true)}
            onOpenNfc={() => setShowNfcModal(true)}
          />
        </div>
      </div>

      {/* AI Copilot Drawer */}
      <AICopilotModal
        card={card}
        isOpen={showAiModal}
        onClose={() => setShowAiModal(false)}
        onApplyText={(field, text) => {
          if (field === 'title') updateField('title', text);
          if (field === 'subtitle') updateField('subtitle', text);
          if (field === 'bio') updateField('bio', text);
        }}
      />

      {/* QR Code Modal */}
      <QRModal
        card={card}
        isOpen={showQrModal}
        onClose={() => setShowQrModal(false)}
        onOpenNfc={() => setShowNfcModal(true)}
      />

      {/* NFC Modal */}
      <NFCModal
        card={card}
        isOpen={showNfcModal}
        onClose={() => setShowNfcModal(false)}
      />
    </div>
  );
};
