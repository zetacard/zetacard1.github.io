import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Card } from '../../types';
import {
  X,
  Copy,
  Check,
  Download,
  Share2,
  ExternalLink,
  Smartphone,
  Radio,
  FileCode,
} from 'lucide-react';
import { downloadVCard } from '../../services/vcard';
import { dbService } from '../../services/db';

interface QRModalProps {
  card: Card;
  isOpen: boolean;
  onClose: () => void;
  onOpenNfc?: () => void;
}

export const QRModal: React.FC<QRModalProps> = ({ card, isOpen, onClose, onOpenNfc }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [copied, setCopied] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const publicUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?card=${card.slug}`
    : `https://zeta-card.base44.app/?card=${card.slug}`;

  useEffect(() => {
    if (!isOpen) return;

    // Increment scan analytics count
    dbService.incrementCardScans(card.id);

    // Generate high resolution QR code
    QRCode.toDataURL(publicUrl, {
      width: 800,
      margin: 2,
      color: {
        dark: card.theme?.primaryColor || '#0ea5e9',
        light: '#030712',
      },
    })
      .then((url) => {
        setQrDataUrl(url);
      })
      .catch((err) => console.error('QR generation error:', err));
  }, [isOpen, publicUrl, card]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadPng = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `ZetaCard-QR-${card.slug}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleWebShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: card.title,
          text: `${card.title} - ${card.subtitle || 'Digital Card'}`,
          url: publicUrl,
        });
      } catch (err) {
        // Share cancelled
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl text-slate-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-5">
          <div className="inline-flex p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 mb-3">
            <Share2 className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold tracking-tight">Scan & Share Card</h3>
          <p className="text-xs text-slate-400 mt-1">
            Dynamic QR code permanently linked to <span className="text-cyan-400 font-semibold">{card.title}</span>
          </p>
        </div>

        {/* QR Code Container */}
        <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-slate-950 border border-slate-800 shadow-inner mb-5">
          {qrDataUrl ? (
            <img
              src={qrDataUrl}
              alt={`QR Code for ${card.title}`}
              className="w-56 h-56 rounded-xl object-contain shadow-lg"
            />
          ) : (
            <div className="w-56 h-56 flex items-center justify-center text-slate-500 text-xs">
              Generating High-Res QR...
            </div>
          )}

          <div className="text-[11px] text-slate-400 mt-3 font-mono">
            Scan with any phone camera to view
          </div>
        </div>

        {/* Shareable URL Copy Input */}
        <div className="flex items-center gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800 mb-5">
          <input
            type="text"
            readOnly
            value={publicUrl}
            className="flex-1 bg-transparent px-2 text-xs font-mono text-slate-300 outline-none truncate"
          />
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-black flex items-center gap-1.5 transition-all cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-black" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                Copy
              </>
            )}
          </button>
        </div>

        {/* Action Buttons Grid */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={handleDownloadPng}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            Download PNG
          </button>

          <button
            onClick={handleWebShare}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Share2 className="w-4 h-4 text-purple-400" />
            Share via App
          </button>
        </div>

        {/* NFC Option if available */}
        {onOpenNfc && (
          <button
            onClick={() => {
              onClose();
              onOpenNfc();
            }}
            className="w-full mt-3 p-3 rounded-xl bg-gradient-to-r from-cyan-950/60 to-blue-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-2 transition-all hover:opacity-90 cursor-pointer"
          >
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            Program to Physical NFC Tag or Card
          </button>
        )}
      </div>
    </div>
  );
};
