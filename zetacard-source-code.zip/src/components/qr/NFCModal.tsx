import React, { useState } from 'react';
import { Card } from '../../types';
import {
  X,
  Radio,
  CheckCircle,
  AlertCircle,
  HelpCircle,
  Smartphone,
  ExternalLink,
  Copy,
  Check,
} from 'lucide-react';
import { checkNfcSupport, writeCardUrlToNfc, NFC_GUIDE_STEPS } from '../../services/nfc';

interface NFCModalProps {
  card: Card;
  isOpen: boolean;
  onClose: () => void;
}

export const NFCModal: React.FC<NFCModalProps> = ({ card, isOpen, onClose }) => {
  const [writing, setWriting] = useState(false);
  const [resultMsg, setResultMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const publicUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?card=${card.slug}`
    : `https://zeta-card.base44.app/?card=${card.slug}`;

  const nfcSupport = checkNfcSupport();

  const handleStartNfcWrite = async () => {
    setWriting(true);
    setResultMsg(null);

    const res = await writeCardUrlToNfc(publicUrl);
    setWriting(false);

    if (res.success) {
      setResultMsg({ type: 'success', text: res.message });
    } else {
      setResultMsg({ type: 'error', text: res.message });
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl text-slate-100 my-8">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight">NFC Digital Card Integration</h3>
            <p className="text-xs text-slate-400">
              Transform physical smart cards and tags into instant ZetaCard touchpoints.
            </p>
          </div>
        </div>

        {/* Real Web NFC API Direct Write Section */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Direct Web NFC Writer
            </span>
            {nfcSupport.supported ? (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Browser Ready
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Manual Guide Required
              </span>
            )}
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mb-4">
            {nfcSupport.supported
              ? 'Click below and hold any blank NTAG213 / NTAG215 / NTAG216 card or sticker to the back of your smartphone.'
              : nfcSupport.reason}
          </p>

          {nfcSupport.supported && (
            <button
              onClick={handleStartNfcWrite}
              disabled={writing}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-98 cursor-pointer disabled:opacity-50"
            >
              <Radio className={`w-4 h-4 ${writing ? 'animate-spin' : ''}`} />
              {writing ? 'Hold NFC tag against phone now...' : 'Write ZetaCard URL to NFC Tag'}
            </button>
          )}

          {resultMsg && (
            <div
              className={`mt-3 p-3 rounded-xl text-xs flex items-start gap-2 ${
                resultMsg.type === 'success'
                  ? 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-300'
                  : 'bg-rose-950/40 border border-rose-500/30 text-rose-300'
              }`}
            >
              {resultMsg.type === 'success' ? (
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
              )}
              <span>{resultMsg.text}</span>
            </div>
          )}
        </div>

        {/* Permanent URL for Tag Writing */}
        <div className="mb-6">
          <label className="text-[11px] uppercase tracking-wider font-semibold text-slate-400 block mb-1.5">
            Card Link to Write onto NFC Tag
          </label>
          <div className="flex items-center gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800">
            <input
              type="text"
              readOnly
              value={publicUrl}
              className="flex-1 bg-transparent px-2 text-xs font-mono text-cyan-300 outline-none truncate"
            />
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
        </div>

        {/* Physical NFC Programming Guide */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-1.5">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            Step-by-Step Physical Tag Guide (iOS & Android)
          </h4>
          <div className="space-y-3">
            {NFC_GUIDE_STEPS.map((item) => (
              <div key={item.step} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs">
                <div className="flex items-center gap-2 font-bold text-cyan-300 mb-1">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-[10px]">
                    {item.step}
                  </span>
                  {item.title}
                </div>
                <p className="text-slate-400 pl-7 text-[11px] leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Ownership Notice */}
        <div className="mt-5 text-center text-[11px] text-slate-500">
          ZetaCard uses universal NDEF standard records ensuring compatibility with 99% of modern smartphones.
        </div>
      </div>
    </div>
  );
};
