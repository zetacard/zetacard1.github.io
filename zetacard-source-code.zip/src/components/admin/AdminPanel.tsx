import React, { useState, useEffect } from 'react';
import { User, Card, Booking, Contact, Enquiry } from '../../types';
import { dbService, subscribeDb } from '../../services/db';
import { authService } from '../../services/auth';
import { ALL_TEMPLATES } from '../../data/templates';
import {
  Shield,
  Users,
  Layers,
  Calendar,
  Activity,
  CheckCircle,
  XCircle,
  Trash2,
  Eye,
  ExternalLink,
  ArrowLeft,
  Server,
  Cpu,
  HardDrive,
  Download,
  AlertTriangle,
  Award,
  Sparkles,
} from 'lucide-react';

interface AdminPanelProps {
  onBack: () => void;
  onViewCard: (card: Card) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onBack, onViewCard }) => {
  const [cards, setCards] = useState<Card[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [adminTab, setAdminTab] = useState<'overview' | 'cards' | 'users' | 'templates' | 'system'>('overview');

  const loadData = () => {
    setCards(dbService.getCards());
    setUsers(authService.getAllUsers());
    setBookings(dbService.getBookings());
    setEnquiries(dbService.getEnquiries());
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeDb(loadData);
    return unsub;
  }, []);

  const totalViews = cards.reduce((acc, c) => acc + (c.viewCount || 0), 0);
  const totalScans = cards.reduce((acc, c) => acc + (c.qrScanCount || 0), 0);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Admin Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Shield className="w-4 h-4" />
              </span>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                ZetaCard Administration & Oversight
              </h1>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Platform Architecture & Owner Controls • <span className="text-cyan-400 font-semibold">Founder: Shahid Tufail</span>
            </p>
          </div>
        </div>

        {/* Creator Attribution Seal */}
        <div className="flex items-center gap-2 p-2.5 rounded-2xl bg-slate-900 border border-slate-800">
          <Award className="w-5 h-5 text-amber-400" />
          <div className="text-left text-xs">
            <span className="block text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Principal Creator</span>
            <span className="font-bold text-amber-300">Shahid Tufail</span>
          </div>
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2 scrollbar-none">
        {[
          { id: 'overview', label: 'Ecosystem Analytics', icon: Activity },
          { id: 'cards', label: `All Cards (${cards.length})`, icon: Layers },
          { id: 'users', label: `User Registry (${users.length})`, icon: Users },
          { id: 'templates', label: `Templates Catalog (${ALL_TEMPLATES.length})`, icon: Sparkles },
          { id: 'system', label: 'System Health & Security', icon: Server },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setAdminTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                adminTab === tab.id
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-md font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {adminTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 font-medium">Total Registered Users</div>
              <div className="text-2xl font-bold font-mono text-white mt-1">{users.length}</div>
              <div className="text-[10px] text-cyan-400 mt-1">Multi-role separation active</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 font-medium">Global Cards Created</div>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">{cards.length}</div>
              <div className="text-[10px] text-emerald-400 mt-1">{cards.filter(c => c.status === 'published').length} Published Live</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 font-medium">Total Card Views</div>
              <div className="text-2xl font-bold font-mono text-purple-400 mt-1">{totalViews.toLocaleString()}</div>
              <div className="text-[10px] text-slate-400 mt-1">Across all public endpoints</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <div className="text-xs text-slate-400 font-medium">QR & NFC Scans</div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1">{totalScans.toLocaleString()}</div>
              <div className="text-[10px] text-slate-400 mt-1">Physical card touchpoints</div>
            </div>
          </div>

          {/* Recent Inquiries and Moderation Queue */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center justify-between">
                <span>Recent Client Inquiries & RSVPs</span>
                <span className="text-xs text-cyan-400 font-mono">{enquiries.length} logged</span>
              </h3>

              <div className="space-y-3">
                {enquiries.slice(0, 5).map((enq) => (
                  <div key={enq.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{enq.senderName}</span>
                      <span className="text-[10px] text-slate-500">{new Date(enq.createdAt).toLocaleDateString()}</span>
                    </div>
                    <div className="text-[11px] text-cyan-400 mt-0.5">{enq.subject}</div>
                    <p className="text-slate-400 mt-1 line-clamp-2">{enq.message}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800">
              <h3 className="text-sm font-bold text-white mb-3">
                System Security & Governance
              </h3>
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-slate-200">Server-Side Gemini AI Safety Proxy</div>
                    <div className="text-[11px] text-slate-400">Endpoint /api/ai/generate with gemini-3.8-flash</div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400">
                    Active
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-slate-200">Crypto PBKDF2 Password Hashing</div>
                    <div className="text-[11px] text-slate-400">Web Crypto API zero-exposure client encryption</div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400">
                    Enforced
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-slate-200">Founder Access Privileges</div>
                    <div className="text-[11px] text-slate-400">iqbaltufail1999@gmail.com verified administrator</div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400">
                    Verified
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ALL CARDS MODERATION */}
      {adminTab === 'cards' && (
        <div className="space-y-4">
          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 border-b border-slate-800 uppercase text-[10px] text-slate-400 font-mono">
                <tr>
                  <th className="p-3.5">Card Name</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Slug</th>
                  <th className="p-3.5">Views</th>
                  <th className="p-3.5">NFC</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {cards.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-bold text-white flex items-center gap-2">
                      <img src={c.profileImageUrl} alt="" className="w-7 h-7 rounded-lg object-cover" />
                      <span>{c.title}</span>
                    </td>
                    <td className="p-3.5 capitalize">{c.category}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          c.status === 'published' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                        }`}
                      >
                        {c.status}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono text-cyan-400">{c.slug}</td>
                    <td className="p-3.5 font-mono">{c.viewCount || 0}</td>
                    <td className="p-3.5">{c.nfcEnabled ? '✓ Enabled' : '—'}</td>
                    <td className="p-3.5 text-right space-x-2">
                      <a
                        href={`?card=${c.slug}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2 py-1 rounded bg-slate-800 text-slate-300 hover:text-white"
                      >
                        Live
                      </a>
                      <button
                        onClick={() => {
                          const newStatus = c.status === 'published' ? 'draft' : 'published';
                          dbService.saveCard({ ...c, status: newStatus });
                        }}
                        className="px-2 py-1 rounded bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
                      >
                        Toggle Status
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: USER REGISTRY */}
      {adminTab === 'users' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {users.map((u) => (
              <div key={u.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="flex items-center gap-3">
                  <img src={u.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'} alt="" className="w-12 h-12 rounded-xl object-cover" />
                  <div>
                    <div className="font-bold text-sm text-white">{u.name}</div>
                    <div className="text-xs text-slate-400 truncate">{u.email}</div>
                    <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-300">
                      {u.role}
                    </span>
                  </div>
                </div>
                <div className="text-[10px] text-slate-500 mt-3 pt-2 border-t border-slate-800">
                  Joined: {new Date(u.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: TEMPLATES CATALOG */}
      {adminTab === 'templates' && (
        <div className="space-y-4">
          <div className="text-xs text-slate-400 mb-2">
            Catalog contains {ALL_TEMPLATES.length} pre-built templates across all 5 disciplines.
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {ALL_TEMPLATES.slice(0, 16).map((t) => (
              <div key={t.id} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
                <img src={t.previewImage} alt="" className="w-full h-24 rounded-lg object-cover mb-2" />
                <div className="font-bold text-white truncate">{t.name}</div>
                <div className="text-[10px] text-cyan-400 capitalize">{t.category} • {t.theme.cardStyle}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: SYSTEM HEALTH */}
      {adminTab === 'system' && (
        <div className="max-w-2xl space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              Runtime Environment & Stack Architecture
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Framework</span>
                <span className="font-bold text-white">React 19 + TypeScript + Vite</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Styling System</span>
                <span className="font-bold text-white">Tailwind CSS v4</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block text-[10px]">AI Integration</span>
                <span className="font-bold text-white">Gemini 3.8 Flash via @google/genai</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Web NFC</span>
                <span className="font-bold text-white">NDEFReader Universal API</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
