import React, { useState, useEffect } from 'react';
import { User, Card, Booking, Contact, Task, Enquiry, CardCategory } from '../../types';
import { dbService, subscribeDb } from '../../services/db';
import { authService } from '../../services/auth';
import { ALL_TEMPLATES } from '../../data/templates';
import { QRModal } from '../qr/QRModal';
import { NFCModal } from '../qr/NFCModal';
import {
  Layers,
  Plus,
  Eye,
  Share2,
  Calendar,
  Users,
  CheckSquare,
  BarChart3,
  Settings,
  Shield,
  Trash2,
  Edit,
  ExternalLink,
  Download,
  Copy,
  Clock,
  CheckCircle,
  XCircle,
  Briefcase,
  Heart,
  PartyPopper,
  Utensils,
  Radio,
  FileDown,
  Upload,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface UserDashboardProps {
  user: User;
  onEditCard: (card: Card) => void;
  onCreateNewCard: (category?: CardCategory) => void;
  onOpenAdmin?: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  user,
  onEditCard,
  onCreateNewCard,
  onOpenAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<'cards' | 'bookings' | 'contacts' | 'tasks' | 'settings'>('cards');
  const [cards, setCards] = useState<Card[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);

  // Selected card for QR/NFC modal
  const [activeModalCard, setActiveModalCard] = useState<Card | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showNfcModal, setShowNfcModal] = useState(false);

  // New task form state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<Task['priority']>('medium');
  const [newTaskDue, setNewTaskDue] = useState(new Date().toISOString().split('T')[0]);

  // Contact search and filter
  const [contactSearch, setContactSearch] = useState('');

  // Reload data from dbService
  const loadData = () => {
    setCards(dbService.getCardsByUser(user.id));
    setBookings(dbService.getBookings(user.id));
    setContacts(dbService.getContacts(user.id));
    setTasks(dbService.getTasks(user.id));
    setEnquiries(dbService.getEnquiries(user.id));
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeDb(loadData);
    return unsub;
  }, [user.id]);

  // Statistics
  const totalCards = cards.length;
  const publishedCards = cards.filter((c) => c.status === 'published').length;
  const totalViews = cards.reduce((acc, c) => acc + (c.viewCount || 0), 0);
  const totalScans = cards.reduce((acc, c) => acc + (c.qrScanCount || 0), 0);
  const pendingBookings = bookings.filter((b) => b.status === 'pending').length;

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    dbService.createTask({
      userId: user.id,
      title: newTaskTitle.trim(),
      priority: newTaskPriority,
      dueDate: newTaskDue,
      completed: false,
      category: 'work',
    });

    setNewTaskTitle('');
  };

  const handleExportContactsCsv = () => {
    const headers = ['Name', 'Email', 'Phone', 'Company', 'Role', 'Status', 'Notes', 'Tags', 'Created'];
    const rows = contacts.map((c) => [
      `"${c.name}"`,
      `"${c.email}"`,
      `"${c.phone}"`,
      `"${c.company || ''}"`,
      `"${c.role || ''}"`,
      `"${c.status}"`,
      `"${(c.notes || '').replace(/"/g, '""')}"`,
      `"${c.tags.join(', ')}"`,
      `"${c.createdAt}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ZetaCard-Contacts-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportBackup = () => {
    const jsonStr = dbService.exportDatabaseJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ZetaCard-Backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const ok = dbService.importDatabaseJson(content);
        if (ok) {
          alert('Database restored successfully from backup!');
          loadData();
        } else {
          alert('Invalid backup file format.');
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Welcome & Quick Overview Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/60 border border-slate-800 shadow-2xl mb-8 overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <img
              src={user.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'}
              alt={user.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-cyan-500/40 p-0.5 shadow-xl bg-slate-800"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                  Welcome back, {user.name}
                </h1>
                {user.role === 'admin' && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Founder / Admin
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                {user.bio || 'Manage your digital cards, appointments, captured contacts, and business agenda.'}
              </p>
            </div>
          </div>

          {/* Quick Create Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onCreateNewCard('business')}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs flex items-center gap-1.5 shadow-lg active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              New Card
            </button>
            {user.role === 'admin' && onOpenAdmin && (
              <button
                onClick={onOpenAdmin}
                className="px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Shield className="w-3.5 h-3.5" />
                Admin Panel
              </button>
            )}
          </div>
        </div>

        {/* Metric Cards Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-6 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="text-[11px] font-medium text-slate-400">Total Cards</div>
            <div className="text-xl sm:text-2xl font-extrabold text-white mt-1 font-mono">
              {totalCards}
            </div>
            <div className="text-[10px] text-emerald-400 mt-0.5 font-medium">
              {publishedCards} Published Live
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="text-[11px] font-medium text-slate-400">Total Card Views</div>
            <div className="text-xl sm:text-2xl font-extrabold text-cyan-400 mt-1 font-mono">
              {totalViews.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Across all links</div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="text-[11px] font-medium text-slate-400">QR / NFC Scans</div>
            <div className="text-xl sm:text-2xl font-extrabold text-purple-400 mt-1 font-mono">
              {totalScans.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Physical touchpoints</div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <div className="text-[11px] font-medium text-slate-400">Pending Bookings</div>
            <div className="text-xl sm:text-2xl font-extrabold text-amber-400 mt-1 font-mono">
              {pendingBookings}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Requires response</div>
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 mb-6 overflow-x-auto scrollbar-none">
        {[
          { id: 'cards', label: `My Cards (${cards.length})`, icon: Layers },
          { id: 'bookings', label: `Appointments (${bookings.length})`, icon: Calendar },
          { id: 'contacts', label: `Contacts CRM (${contacts.length})`, icon: Users },
          { id: 'tasks', label: `Productivity Suite (${tasks.length})`, icon: CheckSquare },
          { id: 'settings', label: 'Settings & Data Backup', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-md font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: CARDS MANAGER */}
      {activeTab === 'cards' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white">Your Digital Cards</h2>
              <p className="text-xs text-slate-400">
                Update, share, generate QR codes, and program physical NFC cards anytime.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onCreateNewCard()}
                className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Create New Card
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cards.map((card) => (
              <div
                key={card.id}
                className="rounded-3xl bg-slate-900 border border-slate-800/80 overflow-hidden shadow-xl hover:border-cyan-500/30 transition-all flex flex-col justify-between"
              >
                {/* Card Header Thumbnail */}
                <div className="relative h-36 bg-slate-950 overflow-hidden">
                  <img
                    src={card.coverImageUrl}
                    alt={card.title}
                    className="w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />

                  <span className="absolute top-3 left-3 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/60 backdrop-blur-md text-cyan-300 border border-cyan-500/30">
                    {card.category}
                  </span>

                  <span
                    className={`absolute top-3 right-3 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      card.status === 'published'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    }`}
                  >
                    {card.status}
                  </span>
                </div>

                {/* Card Details */}
                <div className="p-5 flex-1">
                  <div className="flex items-start gap-3">
                    <img
                      src={card.profileImageUrl}
                      alt={card.title}
                      className="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-700 -mt-8 relative z-10 bg-slate-800 shadow-md"
                    />
                    <div className="overflow-hidden">
                      <h3 className="text-base font-bold text-white truncate">{card.title}</h3>
                      <p className="text-xs text-cyan-400 truncate">{card.subtitle || card.company}</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mt-3 line-clamp-2 leading-relaxed">
                    {card.bio}
                  </p>

                  {/* Analytics pill */}
                  <div className="flex items-center gap-3 mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
                    <div>
                      <span className="font-bold text-slate-200">{card.viewCount || 0}</span> views
                    </div>
                    <div>•</div>
                    <div>
                      <span className="font-bold text-slate-200">{card.qrScanCount || 0}</span> scans
                    </div>
                    <div>•</div>
                    <div>
                      <span className="font-bold text-slate-200">{card.vCardDownloadCount || 0}</span> vCards
                    </div>
                  </div>
                </div>

                {/* Actions Footer */}
                <div className="p-4 bg-slate-950/70 border-t border-slate-800 flex items-center justify-between gap-1.5">
                  <button
                    onClick={() => onEditCard(card)}
                    className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Edit className="w-3.5 h-3.5 text-cyan-400" />
                    Edit
                  </button>

                  <button
                    onClick={() => {
                      setActiveModalCard(card);
                      setShowQrModal(true);
                    }}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
                    title="QR Code & Share"
                  >
                    <Share2 className="w-4 h-4 text-purple-400" />
                  </button>

                  <button
                    onClick={() => {
                      setActiveModalCard(card);
                      setShowNfcModal(true);
                    }}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
                    title="Program NFC Tag"
                  >
                    <Radio className="w-4 h-4 text-cyan-400" />
                  </button>

                  <a
                    href={`?card=${card.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
                    title="Open Live Public Card"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>

                  <button
                    onClick={() => {
                      if (confirm(`Are you sure you want to delete "${card.title}"?`)) {
                        dbService.deleteCard(card.id);
                      }
                    }}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 transition-all cursor-pointer"
                    title="Delete Card"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: BOOKINGS & APPOINTMENTS */}
      {activeTab === 'bookings' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white">Appointment & Meeting Requests</h2>
              <p className="text-xs text-slate-400">
                Manage confirmed bookings, client meetings, and dining reservations.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {bookings.length === 0 ? (
              <div className="p-12 text-center rounded-3xl bg-slate-900 border border-slate-800 text-slate-400">
                <Calendar className="w-10 h-10 mx-auto mb-3 opacity-40 text-cyan-400" />
                <p className="text-sm font-semibold">No booking requests yet</p>
                <p className="text-xs mt-1">When visitors book an appointment through your public card, they will appear here.</p>
              </div>
            ) : (
              bookings.map((booking) => (
                <div
                  key={booking.id}
                  className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">{booking.clientName}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          booking.status === 'confirmed'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : booking.status === 'pending'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {booking.status}
                      </span>
                      <span className="text-xs text-slate-500">via {booking.cardTitle}</span>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
                      <span className="flex items-center gap-1 font-mono text-cyan-300">
                        <Calendar className="w-3.5 h-3.5" /> {booking.date}
                      </span>
                      <span className="flex items-center gap-1 font-mono text-cyan-300">
                        <Clock className="w-3.5 h-3.5" /> {booking.timeSlot}
                      </span>
                      <span>Email: {booking.clientEmail}</span>
                      {booking.clientPhone && <span>Phone: {booking.clientPhone}</span>}
                    </div>

                    {booking.notes && (
                      <p className="text-xs text-slate-300 pt-1 italic">
                        "{booking.notes}"
                      </p>
                    )}
                  </div>

                  {/* Status Action Buttons */}
                  <div className="flex items-center gap-2 shrink-0">
                    {booking.status === 'pending' && (
                      <button
                        onClick={() => dbService.updateBookingStatus(booking.id, 'confirmed')}
                        className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <CheckCircle className="w-3.5 h-3.5" /> Confirm
                      </button>
                    )}

                    {booking.status !== 'cancelled' && (
                      <button
                        onClick={() => dbService.updateBookingStatus(booking.id, 'cancelled')}
                        className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" /> Cancel
                      </button>
                    )}

                    {booking.status === 'confirmed' && (
                      <button
                        onClick={() => dbService.updateBookingStatus(booking.id, 'completed')}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 cursor-pointer"
                      >
                        Mark Completed
                      </button>
                    )}

                    <button
                      onClick={() => dbService.deleteBooking(booking.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 cursor-pointer"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 3: CONTACTS CRM */}
      {activeTab === 'contacts' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">Client Contacts & Business CRM</h2>
              <p className="text-xs text-slate-400">
                Captured leads from public card interactions, RSVP attendees, and bookings.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportContactsCsv}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer"
              >
                <FileDown className="w-3.5 h-3.5 text-cyan-400" />
                Export CSV
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {contacts.map((contact) => (
              <div
                key={contact.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-white">{contact.name}</h3>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                      {contact.status}
                    </span>
                  </div>

                  <div className="text-xs text-slate-400 mt-2 space-y-1">
                    <div>{contact.email}</div>
                    {contact.phone && <div>{contact.phone}</div>}
                    {contact.company && <div className="text-slate-300 font-medium">{contact.company}</div>}
                  </div>

                  {contact.notes && (
                    <div className="mt-3 p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] text-slate-300 leading-relaxed">
                      {contact.notes}
                    </div>
                  )}

                  {contact.tags && contact.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {contact.tags.map((tag) => (
                        <span key={tag} className="px-1.5 py-0.5 rounded text-[9px] bg-slate-800 text-slate-400">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-[10px] text-slate-500">
                    Added {new Date(contact.createdAt).toLocaleDateString()}
                  </span>
                  <button
                    onClick={() => dbService.deleteContact(contact.id)}
                    className="text-slate-500 hover:text-rose-400 cursor-pointer"
                    title="Delete Contact"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: PRODUCTIVITY SUITE */}
      {activeTab === 'tasks' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white">Personal Productivity Suite</h2>
              <p className="text-xs text-slate-400">
                Track client follow-ups, daily agendas, and event deliverables.
              </p>
            </div>
          </div>

          {/* New Task Creator */}
          <form onSubmit={handleCreateTask} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center gap-3">
            <input
              type="text"
              placeholder="What needs to get done today?"
              required
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              className="flex-1 w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
            />

            <select
              value={newTaskPriority}
              onChange={(e) => setNewTaskPriority(e.target.value as any)}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 outline-none"
            >
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
            </select>

            <input
              type="date"
              value={newTaskDue}
              onChange={(e) => setNewTaskDue(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 outline-none"
            />

            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs shrink-0 cursor-pointer"
            >
              Add Task
            </button>
          </form>

          {/* Tasks List */}
          <div className="space-y-2.5">
            {tasks.map((task) => (
              <div
                key={task.id}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition-all ${
                  task.completed
                    ? 'bg-slate-950/40 border-slate-900 opacity-60'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => dbService.toggleTaskCompleted(task.id)}
                    className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
                  />
                  <div>
                    <div className={`text-xs font-semibold ${task.completed ? 'line-through text-slate-400' : 'text-white'}`}>
                      {task.title}
                    </div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>Due: {task.dueDate}</span>
                      <span
                        className={`font-semibold uppercase tracking-wider ${
                          task.priority === 'high' ? 'text-rose-400' : task.priority === 'medium' ? 'text-amber-400' : 'text-slate-400'
                        }`}
                      >
                        {task.priority}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => dbService.deleteTask(task.id)}
                  className="text-slate-500 hover:text-rose-400 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: SETTINGS & BACKUP */}
      {activeTab === 'settings' && (
        <div className="max-w-2xl space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white">Full Database Ownership & Data Export</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              As required by Founder Shahid Tufail's independence mandate, you possess 100% control over your data. You can back up your entire card catalog, bookings, contacts CRM, and productivity tasks into an encrypted JSON payload, or restore it on any device.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href="/zetacard-source-code.zip"
                download="zetacard-source-code.zip"
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg active:scale-95"
              >
                <Download className="w-4 h-4" />
                Download Complete Source Code (.ZIP)
              </a>

              <button
                onClick={handleExportBackup}
                className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-2 cursor-pointer shadow-lg active:scale-95"
              >
                <Download className="w-4 h-4" />
                Export Database JSON
              </button>

              <label className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-2 cursor-pointer transition-all">
                <Upload className="w-4 h-4 text-cyan-400" />
                Restore from Backup
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportBackup}
                  className="hidden"
                />
              </label>

              <button
                onClick={() => {
                  if (confirm('Reset to default seed data? (Shahid Tufail card, sample wedding, and restaurant)')) {
                    dbService.resetToSeed();
                    loadData();
                  }
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-950/40 border border-slate-700 text-slate-400 hover:text-rose-400 font-medium text-xs cursor-pointer ml-auto"
              >
                Reset Database
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QR Code Modal */}
      {activeModalCard && (
        <QRModal
          card={activeModalCard}
          isOpen={showQrModal}
          onClose={() => {
            setShowQrModal(false);
            setActiveModalCard(null);
          }}
          onOpenNfc={() => setShowNfcModal(true)}
        />
      )}

      {/* NFC Modal */}
      {activeModalCard && (
        <NFCModal
          card={activeModalCard}
          isOpen={showNfcModal}
          onClose={() => {
            setShowNfcModal(false);
            setActiveModalCard(null);
          }}
        />
      )}
    </div>
  );
};
