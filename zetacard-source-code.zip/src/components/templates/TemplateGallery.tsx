import React, { useState, useMemo } from 'react';
import { CardCategory, Template, Card } from '../../types';
import { ALL_TEMPLATES } from '../../data/templates';
import { CardMockup } from '../cards/CardMockup';
import {
  Search,
  Filter,
  Sparkles,
  ArrowRight,
  Briefcase,
  Heart,
  PartyPopper,
  Calendar,
  Utensils,
  Layers,
  X,
  Eye,
} from 'lucide-react';

interface TemplateGalleryProps {
  onSelectTemplate: (template: Template) => void;
}

export const TemplateGallery: React.FC<TemplateGalleryProps> = ({ onSelectTemplate }) => {
  const [selectedCategory, setSelectedCategory] = useState<CardCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [previewTemplate, setPreviewTemplate] = useState<Template | null>(null);

  const categories: { id: CardCategory | 'all'; label: string; icon: any; count: number }[] = [
    { id: 'all', label: 'All Categories', icon: Layers, count: ALL_TEMPLATES.length },
    { id: 'business', label: 'Business & Visiting', icon: Briefcase, count: ALL_TEMPLATES.filter((t) => t.category === 'business').length },
    { id: 'wedding', label: 'Wedding Invitations', icon: Heart, count: ALL_TEMPLATES.filter((t) => t.category === 'wedding').length },
    { id: 'birthday', label: 'Birthday Invitations', icon: PartyPopper, count: ALL_TEMPLATES.filter((t) => t.category === 'birthday').length },
    { id: 'event', label: 'Event & Conference', icon: Calendar, count: ALL_TEMPLATES.filter((t) => t.category === 'event').length },
    { id: 'restaurant', label: 'Restaurant Digital Menus', icon: Utensils, count: ALL_TEMPLATES.filter((t) => t.category === 'restaurant').length },
  ];

  const filteredTemplates = useMemo(() => {
    return ALL_TEMPLATES.filter((tpl) => {
      const matchCat = selectedCategory === 'all' || tpl.category === selectedCategory;
      const matchSearch =
        tpl.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tpl.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tpl.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCat && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  // Convert template to dummy Card for previewing
  const previewCard: Card | null = useMemo(() => {
    if (!previewTemplate) return null;
    return {
      id: `preview-${previewTemplate.id}`,
      userId: 'preview-user',
      slug: previewTemplate.id,
      category: previewTemplate.category,
      templateId: previewTemplate.id,
      status: 'published',
      title: previewTemplate.sampleData.title || previewTemplate.name,
      subtitle: previewTemplate.sampleData.subtitle || 'Preview Sample Subtitle',
      company: previewTemplate.sampleData.company || 'Enterprise Corp',
      bio: previewTemplate.sampleData.bio || previewTemplate.description,
      email: previewTemplate.sampleData.email || 'hello@zetacard.app',
      phone: previewTemplate.sampleData.phone || '+1 (555) 019-9000',
      website: previewTemplate.sampleData.website || 'https://zeta-card.base44.app/',
      address: previewTemplate.sampleData.address || 'San Francisco, CA',
      coverImageUrl: previewTemplate.previewImage,
      profileImageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
      socialLinks: [
        { id: '1', platform: 'linkedin', url: 'https://linkedin.com' },
        { id: '2', platform: 'twitter', url: 'https://x.com' },
      ],
      theme: previewTemplate.theme,
      weddingDetails: previewTemplate.sampleData.weddingDetails,
      birthdayDetails: previewTemplate.sampleData.birthdayDetails,
      eventDetails: previewTemplate.sampleData.eventDetails,
      menuCategories: previewTemplate.sampleData.menuCategories,
      menuItems: previewTemplate.sampleData.menuItems,
      services: previewTemplate.sampleData.services,
      viewCount: 120,
      qrScanCount: 45,
      vCardDownloadCount: 20,
      nfcEnabled: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  }, [previewTemplate]);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Gallery Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          Over 100+ Ready-to-Use Premium Templates
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
          Explore The ZetaCard Marketplace
        </h1>
        <p className="text-sm sm:text-base text-slate-400 mt-2.5">
          Select from 20+ bespoke designs across every discipline: visiting cards, luxury weddings, birthdays, global conferences, and digital restaurant menus.
        </p>

        {/* Search Bar */}
        <div className="relative mt-6 max-w-lg mx-auto">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search templates by style, keyword (e.g. minimal, luxury, cyber, neon)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs sm:text-sm text-slate-200 outline-none focus:border-cyan-500 shadow-lg"
          />
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none justify-start sm:justify-center">
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-lg shadow-cyan-500/20 font-bold'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{cat.label}</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  selectedCategory === cat.id ? 'bg-black/20 text-black font-bold' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {cat.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Template Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredTemplates.map((template) => (
          <div
            key={template.id}
            className="group relative rounded-3xl bg-slate-900 border border-slate-800/80 overflow-hidden shadow-xl hover:shadow-2xl hover:border-cyan-500/40 transition-all duration-300 flex flex-col"
          >
            {/* Template Cover Image Preview */}
            <div className="relative h-48 w-full overflow-hidden bg-slate-950">
              <img
                src={template.previewImage}
                alt={template.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-85"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-90" />

              {/* Category Badge */}
              <span className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/60 backdrop-blur-md text-cyan-300 border border-cyan-500/30">
                {template.category}
              </span>

              {/* Style archetype tag */}
              <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[10px] font-medium bg-black/60 backdrop-blur-md text-slate-300 capitalize">
                {template.theme.cardStyle}
              </span>
            </div>

            {/* Template Info Card Body */}
            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition-colors">
                  {template.name}
                </h3>
                <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                  {template.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {template.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 rounded-md text-[10px] bg-slate-950 text-slate-400 border border-slate-800"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Actions Footer */}
              <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setPreviewTemplate(template)}
                  className="px-3 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Preview
                </button>

                <button
                  type="button"
                  onClick={() => onSelectTemplate(template)}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  Use Template
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-16">
          <p className="text-slate-400 text-sm">No templates found matching your search. Try another keyword!</p>
        </div>
      )}

      {/* Full Live Preview Modal */}
      {previewTemplate && previewCard && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl text-slate-100 my-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-base font-bold text-white">{previewTemplate.name}</h4>
                <p className="text-xs text-slate-400 capitalize">{previewTemplate.category} Template</p>
              </div>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Embedded Live Mockup */}
            <div className="max-h-[600px] overflow-hidden rounded-2xl">
              <CardMockup card={previewCard} />
            </div>

            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={() => setPreviewTemplate(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-semibold cursor-pointer"
              >
                Close Preview
              </button>
              <button
                onClick={() => {
                  onSelectTemplate(previewTemplate);
                  setPreviewTemplate(null);
                }}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold text-xs shadow-lg active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                Customize This Template
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
