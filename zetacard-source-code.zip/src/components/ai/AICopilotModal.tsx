import React, { useState } from 'react';
import { Card } from '../../types';
import { requestAiGeneration } from '../../services/ai';
import {
  Sparkles,
  X,
  Check,
  Copy,
  Wand2,
  RefreshCw,
  Send,
  Zap,
} from 'lucide-react';

interface AICopilotModalProps {
  card: Card;
  isOpen: boolean;
  onClose: () => void;
  onApplyText: (field: 'title' | 'subtitle' | 'bio' | 'custom', text: string) => void;
}

export const AICopilotModal: React.FC<AICopilotModalProps> = ({
  card,
  isOpen,
  onClose,
  onApplyText,
}) => {
  const [prompt, setPrompt] = useState('');
  const [generationType, setGenerationType] = useState<'tagline' | 'bio' | 'invitation' | 'menu_item' | 'custom'>(
    card.category === 'restaurant'
      ? 'menu_item'
      : card.category === 'wedding' || card.category === 'birthday' || card.category === 'event'
      ? 'invitation'
      : 'bio'
  );
  const [tone, setTone] = useState<'professional' | 'luxury' | 'creative' | 'friendly' | 'festive'>('professional');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    setLoading(true);
    setResult('');

    const text = await requestAiGeneration({
      type: generationType,
      prompt: prompt || card.title || 'Digital Card Showcase',
      context: {
        category: card.category,
        businessName: card.title,
        industry: card.subtitle || card.company,
        tone,
        details: prompt,
      },
    });

    setLoading(false);
    setResult(text);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApply = (targetField: 'title' | 'subtitle' | 'bio' | 'custom') => {
    onApplyText(targetField, result);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl text-slate-100 my-8">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="p-3 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold tracking-tight">Gemini AI Copilot</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                gemini-3.8-flash
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Instantly draft captivating bios, taglines, invitations, and culinary descriptions.
            </p>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="flex flex-wrap gap-2 mb-4">
          {[
            { id: 'bio', label: 'Professional Bio' },
            { id: 'tagline', label: 'Tagline & Slogan' },
            { id: 'invitation', label: 'Invitation Wording' },
            { id: 'menu_item', label: 'Menu Descriptions' },
            { id: 'custom', label: 'Creative Prompt' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setGenerationType(item.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                generationType === item.id
                  ? 'bg-purple-600 text-white border-purple-500 shadow-md'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Tone Selector */}
        <div className="mb-4">
          <label className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block mb-1.5">
            Voice & Tone
          </label>
          <div className="flex items-center gap-2">
            {(['professional', 'luxury', 'creative', 'friendly', 'festive'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTone(t)}
                className={`px-2.5 py-1 rounded-lg text-xs capitalize transition-all cursor-pointer ${
                  tone === t
                    ? 'bg-slate-700 text-white font-bold border border-slate-600'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Input Details */}
        <div className="mb-4">
          <label className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block mb-1.5">
            Key Highlights or Topic (Optional)
          </label>
          <div className="relative">
            <textarea
              rows={3}
              placeholder={`E.g., "10 years in enterprise architecture, founded 2 SaaS startups, passion for AI workflows..."`}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 outline-none focus:border-purple-500 resize-none pr-10"
            />
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-98 cursor-pointer disabled:opacity-60"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              Crafting with Gemini 3.8 Flash...
            </>
          ) : (
            <>
              <Wand2 className="w-4 h-4" />
              Generate Content Now
            </>
          )}
        </button>

        {/* Result Container */}
        {result && (
          <div className="mt-5 p-4 rounded-2xl bg-slate-950 border border-purple-500/30">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-purple-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Generated Output
              </span>
              <button
                onClick={handleCopy}
                className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>

            <div className="text-xs text-slate-200 whitespace-pre-line leading-relaxed max-h-48 overflow-y-auto pr-1">
              {result}
            </div>

            {/* Quick Apply Actions */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center gap-2">
              <span className="text-[11px] text-slate-400">Apply to card:</span>
              <button
                onClick={() => handleApply('bio')}
                className="px-2.5 py-1 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium cursor-pointer"
              >
                As Bio / Description
              </button>
              <button
                onClick={() => handleApply('subtitle')}
                className="px-2.5 py-1 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium cursor-pointer"
              >
                As Subtitle
              </button>
              <button
                onClick={() => handleApply('title')}
                className="px-2.5 py-1 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium cursor-pointer"
              >
                As Title
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
