import { Card, Booking, Contact, Task, Enquiry, User } from '../types';
import { BUSINESS_TEMPLATES, WEDDING_TEMPLATES, RESTAURANT_TEMPLATES, BIRTHDAY_TEMPLATES, EVENT_TEMPLATES } from '../data/templates';

const DB_KEYS = {
  CARDS: 'zetacard_cards_v1',
  BOOKINGS: 'zetacard_bookings_v1',
  CONTACTS: 'zetacard_contacts_v1',
  TASKS: 'zetacard_tasks_v1',
  ENQUIRIES: 'zetacard_enquiries_v1',
  USERS: 'zetacard_users_v1',
};

// Event bus for cross-component reactivity
const dbEventTarget = new EventTarget();

export function subscribeDb(listener: () => void): () => void {
  const handler = () => listener();
  dbEventTarget.addEventListener('db_change', handler);
  return () => {
    dbEventTarget.removeEventListener('db_change', handler);
  };
}

function notifyChange() {
  dbEventTarget.dispatchEvent(new Event('db_change'));
}

// Initial seed cards
const SEED_CARDS: Card[] = [
  {
    id: 'card-shahid-tufail',
    userId: 'user-shahid-admin',
    slug: 'shahid-tufail',
    category: 'business',
    templateId: 'biz-shahid-signature',
    status: 'published',
    title: 'Shahid Tufail',
    subtitle: 'Founder & Principal Systems Architect',
    company: 'ZetaCard Ecosystem',
    jobTitle: 'Founder & Creator',
    bio: 'Architecting universal, independent digital card infrastructure and productivity tools for entrepreneurs, creators, and organizations worldwide.',
    email: 'iqbaltufail1999@gmail.com',
    phone: '+1 (555) 019-ZETA',
    website: 'https://zeta-card.base44.app/',
    address: 'Global Technology Hub, San Francisco & International',
    mapsUrl: 'https://maps.google.com/?q=San+Francisco',
    coverImageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    profileImageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    socialLinks: [
      { id: '1', platform: 'linkedin', url: 'https://linkedin.com/in/shahid-tufail', label: 'LinkedIn' },
      { id: '2', platform: 'twitter', url: 'https://x.com/shahidtufail', label: 'X (Twitter)' },
      { id: '3', platform: 'github', url: 'https://github.com', label: 'GitHub' },
      { id: '4', platform: 'whatsapp', url: 'https://wa.me/15550199382', label: 'WhatsApp' },
      { id: '5', platform: 'website', url: 'https://zeta-card.base44.app/', label: 'Official Website' },
    ],
    services: [
      { id: 's1', title: 'Digital Transformation Advisory', description: 'Enterprise roadmap and independent cloud architecture strategy.', price: '$250/hr' },
      { id: 's2', title: 'High-Scale Cloud Engineering', description: 'Production systems, microservices, and database optimization.', price: 'Custom' },
      { id: 's3', title: 'AI Integration & Workflows', description: 'Deploying secure, server-side multimodal LLMs for productivity.', price: 'Custom' },
    ],
    theme: {
      primaryColor: '#6366f1',
      secondaryColor: '#06b6d4',
      accentColor: '#f59e0b',
      backgroundColor: '#030712',
      textColor: '#ffffff',
      fontFamily: 'Outfit',
      cardStyle: 'glass',
      borderRadius: 'xl',
      layout: 'standard',
    },
    viewCount: 1420,
    qrScanCount: 489,
    vCardDownloadCount: 215,
    nfcEnabled: true,
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'card-royal-wedding',
    userId: 'user-shahid-admin',
    slug: 'isabella-alexander-wedding',
    category: 'wedding',
    templateId: 'wed-royal-crimson',
    status: 'published',
    title: 'Isabella & Alexander',
    subtitle: 'Together with their families',
    bio: 'We invite you to witness our vows and celebrate the beginning of our forever.',
    email: 'rsvp@isabella-alexander.com',
    phone: '+1 (555) 778-9900',
    address: 'The Grand St. Michael Cathedral, Edinburgh',
    mapsUrl: 'https://maps.google.com/?q=Edinburgh+Castle',
    coverImageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80',
    profileImageUrl: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=600&q=80',
    socialLinks: [
      { id: 'w1', platform: 'instagram', url: 'https://instagram.com', label: '#IsabellaAndAlex2026' },
      { id: 'w2', platform: 'website', url: 'https://isabella-alexander.wedding', label: 'Wedding Registry' },
    ],
    weddingDetails: {
      brideName: 'Isabella Sofia Sterling',
      groomName: 'Alexander James Vance',
      weddingDate: '2026-09-18T16:00:00Z',
      ceremonyTime: '4:00 PM',
      receptionTime: '7:30 PM',
      venueName: 'The Royal St. Michael Cathedral & Castle Ballroom',
      venueAddress: 'High Street Royal Estate, Edinburgh, Scotland',
      mapsUrl: 'https://maps.google.com/?q=Edinburgh',
      story: 'We met on a rainy autumn evening in the university library. Eight years, dozens of countries, and a million shared smiles later, we are overjoyed to embark on our greatest adventure yet.',
      dressCode: 'Black Tie Optional / Royal Evening Elegance',
      registryUrl: 'https://registry.example.com/isabella-alex',
    },
    theme: {
      primaryColor: '#991b1b',
      secondaryColor: '#f59e0b',
      accentColor: '#d97706',
      backgroundColor: '#450a0a',
      textColor: '#fef3c7',
      fontFamily: 'Cinzel',
      cardStyle: 'luxury',
      borderRadius: 'lg',
      layout: 'standard',
    },
    viewCount: 890,
    qrScanCount: 312,
    vCardDownloadCount: 95,
    nfcEnabled: true,
    createdAt: new Date(Date.now() - 14 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'card-bistro-noir',
    userId: 'user-shahid-admin',
    slug: 'le-bistro-noir',
    category: 'restaurant',
    templateId: 'rest-bistro-noir',
    status: 'published',
    title: 'Le Bistro Noir',
    subtitle: 'Authentic French Brasserie & Fine Wine Bar',
    bio: 'Artisan seasonal cuisine celebrating French terroir, heritage recipes, and natural biodynamic wines in an intimate candlelit ambiance.',
    email: 'reservations@lebistronoir.fr',
    phone: '+33 1 43 55 88 99',
    address: '42 Rue de Belleville, 75020 Paris, France',
    mapsUrl: 'https://maps.google.com/?q=Paris+France',
    coverImageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
    profileImageUrl: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=600&q=80',
    socialLinks: [
      { id: 'r1', platform: 'instagram', url: 'https://instagram.com/lebistronoir', label: 'Instagram' },
      { id: 'r2', platform: 'website', url: 'https://lebistronoir.fr', label: 'Menu & Table Booking' },
    ],
    menuCategories: [
      { id: 'cat-starters', name: 'Les Entrées (Starters)', description: 'Classic French starters prepared fresh to order' },
      { id: 'cat-mains', name: 'Les Plats Principaux (Mains)', description: 'Generous artisanal plates from the charcoal hearth' },
      { id: 'cat-desserts', name: 'Les Desserts (Sweets)', description: 'Pastries crafted daily by our pastry chef' },
    ],
    menuItems: [
      { id: 'm1', categoryId: 'cat-starters', name: 'French Onion Soup Gratinée', description: 'Caramelized shallots, rich beef bone broth, sourdough toast, aged Gruyère crust.', price: 16, currency: '€', tags: ['chef_special'], isAvailable: true },
      { id: 'm2', categoryId: 'cat-starters', name: 'Escargots de Bourgogne', description: 'Six wild Burgundy snails baked in garlic herb butter with toasted brioche.', price: 18, currency: '€', tags: ['chef_special'], isAvailable: true },
      { id: 'm3', categoryId: 'cat-mains', name: 'Boeuf Bourguignon Traditionnel', description: 'Braised prime short rib, red Burgundy wine, glazed baby carrots, lardons, pomme purée.', price: 34, currency: '€', tags: ['chef_special'], isAvailable: true },
      { id: 'm4', categoryId: 'cat-mains', name: 'Pan-Roasted Duck Breast', description: 'Spiced honey glaze, parsnip cream, sour cherry reduction.', price: 32, currency: '€', tags: ['gluten_free'], isAvailable: true },
      { id: 'm5', categoryId: 'cat-desserts', name: 'Crème Brûlée à la Vanille', description: 'Tahitian vanilla bean custard with torched caramelized sugar crust.', price: 12, currency: '€', tags: ['vegetarian'], isAvailable: true },
    ],
    theme: {
      primaryColor: '#eab308',
      secondaryColor: '#ca8a04',
      accentColor: '#ffffff',
      backgroundColor: '#18181b',
      textColor: '#fef3c7',
      fontFamily: 'Playfair Display',
      cardStyle: 'luxury',
      borderRadius: 'lg',
      layout: 'standard',
    },
    viewCount: 2310,
    qrScanCount: 1450,
    vCardDownloadCount: 420,
    nfcEnabled: true,
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'card-global-ai-summit',
    userId: 'user-shahid-admin',
    slug: 'global-ai-summit-2026',
    category: 'event',
    templateId: 'evt-tech-summit',
    status: 'published',
    title: 'Global AI Summit 2026',
    subtitle: 'The Frontier of Autonomous Intelligence & Systems',
    bio: 'Join 5,000+ AI researchers, engineers, and founders exploring breakthroughs in multimodal reasoning and agentic architectures.',
    email: 'info@aisummit2026.org',
    phone: '+1 (415) 555-0192',
    address: 'Moscone West Convention Center, San Francisco, CA',
    mapsUrl: 'https://maps.google.com/?q=Moscone+Center',
    coverImageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80',
    profileImageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80',
    socialLinks: [
      { id: 'e1', platform: 'twitter', url: 'https://x.com/aisummit2026', label: '#GlobalAISummit' },
      { id: 'e2', platform: 'linkedin', url: 'https://linkedin.com', label: 'Summit LinkedIn' },
    ],
    eventDetails: {
      eventTitle: 'Global AI Summit 2026',
      organizer: 'Zeta Intelligence Research',
      startDate: '2026-11-15T09:00:00Z',
      endDate: '2026-11-17T18:00:00Z',
      location: 'Moscone West Convention Center, San Francisco, CA',
      virtualLink: 'https://summit.zetacard.app/live',
      schedule: [
        { time: '09:00 AM', title: 'Keynote: Engineering Independent AI Platforms', speaker: 'Shahid Tufail' },
        { time: '11:30 AM', title: 'Breakout: Distributed Vector Architectures & Memory', speaker: 'Dr. Elena Rostova' },
        { time: '02:00 PM', title: 'Workshop: Hands-on Gemini 3.8 Multimodal Agents', speaker: 'Alex Thorne' },
      ],
      speakers: [
        { name: 'Shahid Tufail', role: 'Principal Architect & Founder', company: 'ZetaCard', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80' },
        { name: 'Dr. Elena Rostova', role: 'Chief Scientist', company: 'BioIntelligence AI', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80' },
      ],
      ticketInfo: {
        price: 'Complimentary Pass / $299 All-Access VIP',
        link: '#register',
        badge: 'Registration Open',
      },
    },
    theme: {
      primaryColor: '#6366f1',
      secondaryColor: '#06b6d4',
      accentColor: '#10b981',
      backgroundColor: '#090d16',
      textColor: '#f8fafc',
      fontFamily: 'Space Grotesk',
      cardStyle: 'glass',
      borderRadius: 'lg',
      layout: 'standard',
    },
    viewCount: 3120,
    qrScanCount: 1820,
    vCardDownloadCount: 680,
    nfcEnabled: true,
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'card-neon-birthday',
    userId: 'user-shahid-admin',
    slug: 'maya-turning-30',
    category: 'birthday',
    templateId: 'bday-confetti-neon',
    status: 'published',
    title: 'Maya is Turning 30!',
    subtitle: 'Rooftop Neon Party & Cocktail Night',
    bio: 'Leave the everyday behind and celebrate three glorious decades with great beats, signature cocktails, and breathtaking views.',
    email: 'maya@patel.me',
    phone: '+1 (555) 432-1100',
    address: 'Skyline Penthouse Lounge, 550 5th Avenue, New York, NY',
    mapsUrl: 'https://maps.google.com/?q=New+York',
    coverImageUrl: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1200&q=80',
    profileImageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    socialLinks: [
      { id: 'b1', platform: 'instagram', url: 'https://instagram.com', label: '#MayaLevel30' },
    ],
    birthdayDetails: {
      honoreeName: 'Maya Patel',
      turningAge: 30,
      birthDate: '2026-06-15',
      partyTime: '8:00 PM Till 2:00 AM',
      venueName: 'Skyline Penthouse Rooftop Lounge',
      venueAddress: '550 5th Avenue, 45th Floor, New York, NY',
      theme: 'Glow in the Dark Neon Glam',
      customMessage: 'Dress in your boldest neon or black party fits! Music by DJ Nova. RSVP by June 8 so we can reserve your guest passes.',
      rsvpDeadline: '2026-06-08',
    },
    theme: {
      primaryColor: '#ec4899',
      secondaryColor: '#8b5cf6',
      accentColor: '#38bdf8',
      backgroundColor: '#0f172a',
      textColor: '#ffffff',
      fontFamily: 'Outfit',
      cardStyle: 'neon',
      borderRadius: 'xl',
      layout: 'floating',
    },
    viewCount: 640,
    qrScanCount: 280,
    vCardDownloadCount: 45,
    nfcEnabled: true,
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

const SEED_BOOKINGS: Booking[] = [
  {
    id: 'book-1',
    cardId: 'card-shahid-tufail',
    cardTitle: 'Shahid Tufail - Founder',
    ownerId: 'user-shahid-admin',
    clientName: 'Marcus Reynolds',
    clientEmail: 'marcus.reynolds@apexventures.io',
    clientPhone: '+1 (415) 555-8921',
    date: '2026-11-12',
    timeSlot: '10:00 AM - 10:45 AM',
    status: 'confirmed',
    notes: 'Discussion on deploying ZetaCard ecosystem across enterprise teams.',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: 'book-2',
    cardId: 'card-shahid-tufail',
    cardTitle: 'Shahid Tufail - Founder',
    ownerId: 'user-shahid-admin',
    clientName: 'Sarah Jenkins',
    clientEmail: 'sarah.jenkins@healthcore.org',
    clientPhone: '+1 (312) 555-4301',
    date: '2026-11-14',
    timeSlot: '02:00 PM - 02:45 PM',
    status: 'pending',
    notes: 'Interested in digital doctor visiting cards and NFC badge integration.',
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
  {
    id: 'book-3',
    cardId: 'card-bistro-noir',
    cardTitle: 'Le Bistro Noir',
    ownerId: 'user-shahid-admin',
    clientName: 'Julian & Claire Vance',
    clientEmail: 'julian@vanceestates.com',
    clientPhone: '+33 6 12 34 56 78',
    date: '2026-11-13',
    timeSlot: '08:00 PM - 10:00 PM',
    status: 'confirmed',
    notes: 'Anniversary dinner table by the window. 2 guests.',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
];

const SEED_CONTACTS: Contact[] = [
  {
    id: 'contact-1',
    ownerId: 'user-shahid-admin',
    sourceCardId: 'card-shahid-tufail',
    name: 'Marcus Reynolds',
    email: 'marcus.reynolds@apexventures.io',
    phone: '+1 (415) 555-8921',
    company: 'Apex Ventures',
    role: 'Managing Director',
    tags: ['VIP', 'Enterprise', 'Partner'],
    notes: 'Met at Tech Summit. Very enthusiastic about ZetaCard white-labeling.',
    status: 'client',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: 'contact-2',
    ownerId: 'user-shahid-admin',
    sourceCardId: 'card-shahid-tufail',
    name: 'Elena Rostova',
    email: 'elena@verdant.eco',
    phone: '+44 20 7946 0192',
    company: 'Verdant Earth BioLabs',
    role: 'Chief Sustainability Officer',
    tags: ['Speaker', 'Innovator'],
    notes: 'Co-speaker for Global AI Summit keynote.',
    status: 'contacted',
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
  },
  {
    id: 'contact-3',
    ownerId: 'user-shahid-admin',
    sourceCardId: 'card-bistro-noir',
    name: 'Henri Delacroix',
    email: 'henri@sommelier-paris.fr',
    phone: '+33 1 42 00 11 22',
    company: 'Sommelier Guild France',
    role: 'President',
    tags: ['Hospitality', 'Sommelier'],
    notes: 'Interested in partnering on digital QR wine menus.',
    status: 'new',
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
];

const SEED_TASKS: Task[] = [
  {
    id: 'task-1',
    userId: 'user-shahid-admin',
    title: 'Review ZetaCard NFC tag programming guide',
    description: 'Ensure NDEFReader Web NFC API flows work seamlessly on Android Chrome.',
    priority: 'high',
    dueDate: '2026-11-10',
    completed: true,
    category: 'work',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task-2',
    userId: 'user-shahid-admin',
    title: 'Prepare Keynote Slides for Global AI Summit',
    description: 'Autonomous AI Copilot capabilities and server-side safety in production.',
    priority: 'high',
    dueDate: '2026-11-14',
    completed: false,
    category: 'event',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task-3',
    userId: 'user-shahid-admin',
    title: 'Follow up with Marcus Reynolds regarding enterprise rollout',
    description: 'Send contract draft and custom domain instructions.',
    priority: 'medium',
    dueDate: '2026-11-13',
    completed: false,
    category: 'client',
    createdAt: new Date().toISOString(),
  },
];

const SEED_ENQUIRIES: Enquiry[] = [
  {
    id: 'enq-1',
    cardId: 'card-shahid-tufail',
    ownerId: 'user-shahid-admin',
    senderName: 'David K. Miller',
    senderEmail: 'david@matrixgrowth.com',
    senderPhone: '+1 (650) 555-8711',
    subject: 'Partnership Inquiry for ZetaCard',
    message: 'Hello Shahid, I reviewed your ZetaCard architecture and we would love to integrate your QR & NFC digital card stack across our 400-person sales team.',
    status: 'unread',
    createdAt: new Date(Date.now() - 4 * 3600000).toISOString(),
  },
  {
    id: 'enq-2',
    cardId: 'card-royal-wedding',
    ownerId: 'user-shahid-admin',
    senderName: 'Lady Catherine Spencer',
    senderEmail: 'cspencer@mayfair.co.uk',
    subject: 'Wedding RSVP & Dietary Requirements',
    message: 'Delighted to confirm attendance for 2 guests. We both require gluten-free dining during the reception.',
    status: 'read',
    createdAt: new Date(Date.now() - 24 * 3600000).toISOString(),
  },
];

// Helper to read/write localStorage
function getStored<T>(key: string, defaultVal: T): T {
  try {
    const val = localStorage.getItem(key);
    if (!val) {
      localStorage.setItem(key, JSON.stringify(defaultVal));
      return defaultVal;
    }
    return JSON.parse(val);
  } catch {
    return defaultVal;
  }
}

function setStored<T>(key: string, val: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(val));
    notifyChange();
  } catch (e) {
    console.error('Storage error:', e);
  }
}

// Database Service APIs
export const dbService = {
  // Cards
  getCards(): Card[] {
    return getStored<Card[]>(DB_KEYS.CARDS, SEED_CARDS);
  },

  getCardsByUser(userId: string): Card[] {
    const all = this.getCards();
    return all.filter((c) => c.userId === userId || userId === 'user-shahid-admin');
  },

  getCardById(id: string): Card | undefined {
    return this.getCards().find((c) => c.id === id);
  },

  getCardBySlug(slug: string): Card | undefined {
    return this.getCards().find((c) => c.slug.toLowerCase() === slug.toLowerCase());
  },

  saveCard(card: Card): Card {
    const cards = this.getCards();
    const index = cards.findIndex((c) => c.id === card.id);
    const updated = {
      ...card,
      updatedAt: new Date().toISOString(),
    };

    if (index >= 0) {
      cards[index] = updated;
    } else {
      cards.unshift(updated);
    }

    setStored(DB_KEYS.CARDS, cards);
    return updated;
  },

  deleteCard(id: string): void {
    const cards = this.getCards().filter((c) => c.id !== id);
    setStored(DB_KEYS.CARDS, cards);
  },

  incrementCardViews(id: string): void {
    const cards = this.getCards();
    const card = cards.find((c) => c.id === id);
    if (card) {
      card.viewCount = (card.viewCount || 0) + 1;
      setStored(DB_KEYS.CARDS, cards);
    }
  },

  incrementCardScans(id: string): void {
    const cards = this.getCards();
    const card = cards.find((c) => c.id === id);
    if (card) {
      card.qrScanCount = (card.qrScanCount || 0) + 1;
      setStored(DB_KEYS.CARDS, cards);
    }
  },

  incrementCardVcard(id: string): void {
    const cards = this.getCards();
    const card = cards.find((c) => c.id === id);
    if (card) {
      card.vCardDownloadCount = (card.vCardDownloadCount || 0) + 1;
      setStored(DB_KEYS.CARDS, cards);
    }
  },

  // Bookings
  getBookings(ownerId?: string): Booking[] {
    const bookings = getStored<Booking[]>(DB_KEYS.BOOKINGS, SEED_BOOKINGS);
    if (!ownerId) return bookings;
    return bookings.filter((b) => b.ownerId === ownerId || ownerId === 'user-shahid-admin');
  },

  createBooking(bookingData: Omit<Booking, 'id' | 'createdAt'>): Booking {
    const bookings = this.getBookings();
    const newBooking: Booking = {
      ...bookingData,
      id: `book-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    bookings.unshift(newBooking);
    setStored(DB_KEYS.BOOKINGS, bookings);
    return newBooking;
  },

  updateBookingStatus(id: string, status: Booking['status']): Booking | null {
    const bookings = this.getBookings();
    const b = bookings.find((x) => x.id === id);
    if (b) {
      b.status = status;
      setStored(DB_KEYS.BOOKINGS, bookings);
      return b;
    }
    return null;
  },

  deleteBooking(id: string): void {
    const bookings = this.getBookings().filter((b) => b.id !== id);
    setStored(DB_KEYS.BOOKINGS, bookings);
  },

  // Contacts CRM
  getContacts(ownerId?: string): Contact[] {
    const contacts = getStored<Contact[]>(DB_KEYS.CONTACTS, SEED_CONTACTS);
    if (!ownerId) return contacts;
    return contacts.filter((c) => c.ownerId === ownerId || ownerId === 'user-shahid-admin');
  },

  createContact(contactData: Omit<Contact, 'id' | 'createdAt'>): Contact {
    const contacts = this.getContacts();
    const newContact: Contact = {
      ...contactData,
      id: `contact-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    contacts.unshift(newContact);
    setStored(DB_KEYS.CONTACTS, contacts);
    return newContact;
  },

  updateContact(contact: Contact): void {
    const contacts = this.getContacts();
    const index = contacts.findIndex((c) => c.id === contact.id);
    if (index >= 0) {
      contacts[index] = contact;
      setStored(DB_KEYS.CONTACTS, contacts);
    }
  },

  deleteContact(id: string): void {
    const contacts = this.getContacts().filter((c) => c.id !== id);
    setStored(DB_KEYS.CONTACTS, contacts);
  },

  // Tasks
  getTasks(userId?: string): Task[] {
    const tasks = getStored<Task[]>(DB_KEYS.TASKS, SEED_TASKS);
    if (!userId) return tasks;
    return tasks.filter((t) => t.userId === userId || userId === 'user-shahid-admin');
  },

  createTask(taskData: Omit<Task, 'id' | 'createdAt'>): Task {
    const tasks = this.getTasks();
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    tasks.unshift(newTask);
    setStored(DB_KEYS.TASKS, tasks);
    return newTask;
  },

  toggleTaskCompleted(id: string): Task | null {
    const tasks = this.getTasks();
    const t = tasks.find((x) => x.id === id);
    if (t) {
      t.completed = !t.completed;
      setStored(DB_KEYS.TASKS, tasks);
      return t;
    }
    return null;
  },

  deleteTask(id: string): void {
    const tasks = this.getTasks().filter((t) => t.id !== id);
    setStored(DB_KEYS.TASKS, tasks);
  },

  // Enquiries
  getEnquiries(ownerId?: string): Enquiry[] {
    const enqs = getStored<Enquiry[]>(DB_KEYS.ENQUIRIES, SEED_ENQUIRIES);
    if (!ownerId) return enqs;
    return enqs.filter((e) => e.ownerId === ownerId || ownerId === 'user-shahid-admin');
  },

  createEnquiry(data: Omit<Enquiry, 'id' | 'createdAt'>): Enquiry {
    const enqs = this.getEnquiries();
    const newEnq: Enquiry = {
      ...data,
      id: `enq-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };
    enqs.unshift(newEnq);
    setStored(DB_KEYS.ENQUIRIES, enqs);

    // Also auto-save to contacts CRM!
    this.createContact({
      ownerId: data.ownerId,
      sourceCardId: data.cardId,
      name: data.senderName,
      email: data.senderEmail,
      phone: data.senderPhone || '',
      tags: ['Inquiry Lead'],
      notes: `Sent inquiry: "${data.subject}" - ${data.message}`,
      status: 'new',
    });

    return newEnq;
  },

  markEnquiryRead(id: string): void {
    const enqs = this.getEnquiries();
    const e = enqs.find((x) => x.id === id);
    if (e && e.status === 'unread') {
      e.status = 'read';
      setStored(DB_KEYS.ENQUIRIES, enqs);
    }
  },

  // System Backup & Restore
  exportDatabaseJson(): string {
    const payload = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      creator: 'Shahid Tufail',
      platform: 'ZetaCard Ecosystem',
      data: {
        cards: this.getCards(),
        bookings: this.getBookings(),
        contacts: this.getContacts(),
        tasks: this.getTasks(),
        enquiries: this.getEnquiries(),
      },
    };
    return JSON.stringify(payload, null, 2);
  },

  importDatabaseJson(jsonStr: string): boolean {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.data) {
        if (Array.isArray(parsed.data.cards)) setStored(DB_KEYS.CARDS, parsed.data.cards);
        if (Array.isArray(parsed.data.bookings)) setStored(DB_KEYS.BOOKINGS, parsed.data.bookings);
        if (Array.isArray(parsed.data.contacts)) setStored(DB_KEYS.CONTACTS, parsed.data.contacts);
        if (Array.isArray(parsed.data.tasks)) setStored(DB_KEYS.TASKS, parsed.data.tasks);
        if (Array.isArray(parsed.data.enquiries)) setStored(DB_KEYS.ENQUIRIES, parsed.data.enquiries);
        return true;
      }
      return false;
    } catch (e) {
      console.error('Import failed:', e);
      return false;
    }
  },

  resetToSeed(): void {
    setStored(DB_KEYS.CARDS, SEED_CARDS);
    setStored(DB_KEYS.BOOKINGS, SEED_BOOKINGS);
    setStored(DB_KEYS.CONTACTS, SEED_CONTACTS);
    setStored(DB_KEYS.TASKS, SEED_TASKS);
    setStored(DB_KEYS.ENQUIRIES, SEED_ENQUIRIES);
  },
};
