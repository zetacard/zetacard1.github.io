export interface AiGenerationOptions {
  type: 'tagline' | 'bio' | 'invitation' | 'menu_item' | 'custom';
  prompt: string;
  context?: {
    category?: string;
    businessName?: string;
    industry?: string;
    tone?: 'professional' | 'luxury' | 'creative' | 'friendly' | 'festive';
    details?: string;
  };
}

export async function requestAiGeneration(options: AiGenerationOptions): Promise<string> {
  try {
    const res = await fetch('/api/ai/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(options),
    });

    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }

    const data = await res.json();
    if (data.error) {
      console.warn('AI Server responded with error, using smart fallback:', data.error);
      return getSmartFallback(options);
    }

    if (data.text) {
      return data.text.trim();
    }

    return getSmartFallback(options);
  } catch (err) {
    console.warn('AI request failed, applying smart fallback generator:', err);
    return getSmartFallback(options);
  }
}

function getSmartFallback(options: AiGenerationOptions): string {
  const { type, context, prompt } = options;

  if (type === 'tagline') {
    const name = context?.businessName || prompt || 'ZetaCard';
    return [
      `1. ${name} — Architecting Precision, Delivering Excellence.`,
      `2. Redefining possibilities through visionary craftsmanship.`,
      `3. Seamless innovation for high-velocity creators and enterprises.`,
      `4. Empowering your digital presence with zero compromise.`,
      `5. The pinnacle of modern professionalism, always one tap away.`,
    ].join('\n');
  }

  if (type === 'bio') {
    const name = context?.businessName || prompt || 'Professional';
    const role = context?.industry || 'Senior Specialist';
    return `${name} is an accomplished ${role} known for delivering high-impact solutions, strategic clarity, and disciplined execution. With a relentless focus on client value and modern innovation, ${name} bridges creative vision with operational rigor.\n\nWhether leading multi-stakeholder initiatives or crafting bespoke experiences, every project is anchored in precision, integrity, and future-ready excellence. Let's connect and build something extraordinary together.`;
  }

  if (type === 'invitation') {
    const cat = context?.category || 'Celebration';
    if (cat.toLowerCase().includes('wedding')) {
      return `Two lives, two hearts, joined together in friendship and united forever in love.\n\nWith immense joy and gratitude, we invite you to share in our happiness as we exchange marriage vows and celebrate the dawn of our new chapter together.\n\nYour presence, blessings, and laughter will make our special day complete. Kindly RSVP at your earliest convenience.`;
    }
    if (cat.toLowerCase().includes('birthday')) {
      return `Another year of unforgettable adventures, vibrant memories, and cherished friendships!\n\nYou are cordially invited to raise a glass, hit the dance floor, and celebrate this special milestone with us.\n\nGet ready for extraordinary music, great bites, and laughter under the stars. Don't forget to RSVP so we can reserve your welcome pass!`;
    }
    return `We are honored to invite you to this landmark gathering.\n\nJoin industry visionaries, creative innovators, and pioneers for an immersive session of keynote insights, meaningful networking, and collaborative dialogue.\n\nPlease reserve your confirmation below. We look forward to welcoming you!`;
  }

  if (type === 'menu_item') {
    return `Slow-braised with aromatic herbs and finished with a silky reduction of natural pan juices. Served over velvet purée and garnished with crisp micro-greens and a touch of cold-pressed virgin olive oil for an unforgettable balance of flavor and texture.`;
  }

  return `Crafted with meticulous attention to detail, balancing modern aesthetics with timeless performance.`;
}
