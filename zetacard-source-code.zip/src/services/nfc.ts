export interface NfcSupportStatus {
  supported: boolean;
  reason?: string;
}

export function checkNfcSupport(): NfcSupportStatus {
  if (typeof window === 'undefined') {
    return { supported: false, reason: 'Non-browser environment' };
  }

  // Web NFC is supported primarily in Chrome for Android
  if (!('NDEFReader' in window)) {
    return {
      supported: false,
      reason: 'Web NFC is not supported in this browser. To write NFC tags directly from the web, please use Google Chrome on an NFC-enabled Android device. On iOS or desktop, use the free NFC Tools app with your card URL.',
    };
  }

  return { supported: true };
}

export async function writeCardUrlToNfc(url: string): Promise<{ success: boolean; message: string }> {
  const support = checkNfcSupport();
  if (!support.supported) {
    return {
      success: false,
      message: support.reason || 'Web NFC is not supported on this device.',
    };
  }

  try {
    const NDEFReaderClass = (window as any).NDEFReader;
    const ndef = new NDEFReaderClass();

    // Prompt user to tap tag
    await ndef.write({
      records: [
        {
          recordType: 'url',
          data: url,
        },
      ],
    });

    return {
      success: true,
      message: 'Successfully written ZetaCard URL to NFC tag! Tap any modern smartphone to open your card instantly.',
    };
  } catch (error: any) {
    console.error('NFC Write Error:', error);
    if (error.name === 'NotAllowedError') {
      return { success: false, message: 'NFC permission was denied by the user.' };
    }
    if (error.name === 'NotSupportedError') {
      return { success: false, message: 'NFC hardware is disabled or unsupported on this device.' };
    }
    return { success: false, message: error.message || 'Failed to write to NFC tag. Please try again.' };
  }
}

export const NFC_GUIDE_STEPS = [
  {
    step: 1,
    title: 'Acquire Compatible NFC Tags',
    desc: 'Get any standard NTAG213, NTAG215, or NTAG216 NFC tags, cards, stickers, or metal smart cards from Amazon or electronics retailers.',
  },
  {
    step: 2,
    title: 'Copy Your ZetaCard Public URL',
    desc: 'Each card has a permanent, unique link that never changes even when you edit your card details.',
  },
  {
    step: 3,
    title: 'Program with Web NFC or NFC Tools',
    desc: 'On Android Chrome: Click "Write to NFC Tag" above and tap your card to the back of your phone. On iPhone or other devices: Open the free "NFC Tools" app, select "Write" -> "Add a record" -> "URL", paste your ZetaCard link, and tap "Write".',
  },
  {
    step: 4,
    title: 'Tap & Share Effortlessly',
    desc: 'Hold your programmed NFC card near any iPhone (XR or newer) or modern Android. The card instantly opens in their browser without requiring any app!',
  },
];
