import { Card } from '../types';

export function generateVCard(card: Card): string {
  const lines: string[] = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `FN:${card.title || 'Contact'}`,
    `N:${card.title ? card.title.split(' ').reverse().join(';') : 'Contact'};;;`,
  ];

  if (card.company) {
    lines.push(`ORG:${card.company}`);
  }

  if (card.jobTitle || card.subtitle) {
    lines.push(`TITLE:${card.jobTitle || card.subtitle}`);
  }

  if (card.email) {
    lines.push(`EMAIL;TYPE=INTERNET,PREF:${card.email}`);
  }

  if (card.phone) {
    lines.push(`TEL;TYPE=CELL,VOICE,PREF:${card.phone}`);
  }

  if (card.website) {
    lines.push(`URL:${card.website}`);
  }

  if (card.address) {
    lines.push(`ADR;TYPE=WORK:;;${card.address.replace(/,/g, '\\,')};;;;`);
  }

  if (card.bio) {
    const cleanBio = card.bio.replace(/\n/g, '\\n').replace(/,/g, '\\,');
    lines.push(`NOTE:${cleanBio}`);
  }

  // Social profiles as X-SOCIALPROFILE
  if (card.socialLinks && card.socialLinks.length > 0) {
    card.socialLinks.forEach((link) => {
      if (link.url) {
        lines.push(`X-SOCIALPROFILE;type=${link.platform}:${link.url}`);
      }
    });
  }

  lines.push('END:VCARD');
  return lines.join('\r\n');
}

export function downloadVCard(card: Card): void {
  const vcardContent = generateVCard(card);
  const blob = new Blob([vcardContent], { type: 'text/vcard;charset=utf-8;' });
  const filename = `${(card.slug || 'contact').toLowerCase()}.vcf`;

  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
