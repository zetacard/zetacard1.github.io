import { User } from '../types';

const AUTH_USER_KEY = 'zetacard_auth_user_v1';
const REGISTERED_USERS_KEY = 'zetacard_registered_users_v1';

// Seed users
const SEED_USERS: User[] = [
  {
    id: 'user-shahid-admin',
    email: 'iqbaltufail1999@gmail.com',
    name: 'Shahid Tufail',
    role: 'admin',
    company: 'ZetaCard Ecosystem',
    bio: 'Founder, Principal Systems Architect & Creator of ZetaCard.',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    phone: '+1 (555) 019-ZETA',
    createdAt: new Date('2025-01-01').toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'user-creator-elena',
    email: 'elena@zetacard.app',
    name: 'Elena Vance',
    role: 'creator',
    company: 'Vance Design Studio',
    bio: 'Digital artist and wedding event organizer.',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    phone: '+1 (555) 432-8899',
    createdAt: new Date('2025-06-01').toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'user-bistro-owner',
    email: 'matteo@lebistronoir.fr',
    name: 'Chef Matteo Rossi',
    role: 'user',
    company: 'Le Bistro Noir',
    bio: 'Culinary director and restaurant owner in Paris.',
    avatarUrl: 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=300&q=80',
    phone: '+33 1 43 55 88 99',
    createdAt: new Date('2025-08-10').toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// In-memory / storage registered user credentials (email -> { user, passwordHash })
interface StoredUserCredential {
  user: User;
  passwordHash: string;
}

const authEventTarget = new EventTarget();

export function subscribeAuth(listener: (user: User | null) => void): () => void {
  const handler = () => listener(authService.getCurrentUser());
  authEventTarget.addEventListener('auth_change', handler);
  return () => {
    authEventTarget.removeEventListener('auth_change', handler);
  };
}

function notifyAuth() {
  authEventTarget.dispatchEvent(new Event('auth_change'));
}

async function hashPassword(password: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(password + '_zetacard_salt_2026');
  const hashBuf = await crypto.subtle.digest('SHA-256', data);
  const hashArr = Array.from(new Uint8Array(hashBuf));
  return hashArr.map((b) => b.toString(16).padStart(2, '0')).join('');
}

function getStoredUsers(): StoredUserCredential[] {
  try {
    const raw = localStorage.getItem(REGISTERED_USERS_KEY);
    if (!raw) {
      // Initialize with seed users
      const initial: StoredUserCredential[] = SEED_USERS.map((u) => ({
        user: u,
        // password hash for default 'password123' or 'admin123'
        passwordHash: '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918',
      }));
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveStoredUsers(users: StoredUserCredential[]) {
  localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(users));
}

export const authService = {
  getCurrentUser(): User | null {
    try {
      const raw = localStorage.getItem(AUTH_USER_KEY);
      if (!raw) {
        // Default to Founder Shahid Tufail for immediate smooth experience
        const defaultUser = SEED_USERS[0];
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(defaultUser));
        return defaultUser;
      }
      return JSON.parse(raw);
    } catch {
      return SEED_USERS[0];
    }
  },

  async login(email: string, password: string):Promise<{ success: boolean; error?: string; user?: User }> {
    const users = getStoredUsers();
    const candidate = users.find((u) => u.user.email.toLowerCase() === email.trim().toLowerCase());

    if (!candidate) {
      return { success: false, error: 'No account found with this email. Please register.' };
    }

    const hashed = await hashPassword(password);
    // Allow either exact hash match or standard demo passwords
    if (candidate.passwordHash === hashed || password === 'password123' || password === 'admin123') {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(candidate.user));
      notifyAuth();
      return { success: true, user: candidate.user };
    }

    return { success: false, error: 'Invalid password. Please check and try again.' };
  },

  async register(name: string, email: string, password: string, role: User['role'] = 'user'): Promise<{ success: boolean; error?: string; user?: User }> {
    if (!name.trim() || !email.trim() || !password) {
      return { success: false, error: 'Please fill in all required fields.' };
    }

    const users = getStoredUsers();
    const existing = users.find((u) => u.user.email.toLowerCase() === email.trim().toLowerCase());
    if (existing) {
      return { success: false, error: 'An account with this email already exists. Please log in.' };
    }

    // Assign admin role if email matches Shahid Tufail's verified emails
    const isAdminEmail = email.trim().toLowerCase() === 'iqbaltufail1999@gmail.com' || email.trim().toLowerCase() === 'admin@zetacard.app';
    const finalRole = isAdminEmail ? 'admin' : role;

    const newUser: User = {
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      email: email.trim().toLowerCase(),
      name: name.trim(),
      role: finalRole,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const passwordHash = await hashPassword(password);
    users.push({ user: newUser, passwordHash });
    saveStoredUsers(users);

    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(newUser));
    notifyAuth();

    return { success: true, user: newUser };
  },

  switchUser(user: User): void {
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
    notifyAuth();
  },

  logout(): void {
    localStorage.removeItem(AUTH_USER_KEY);
    notifyAuth();
  },

  getSeedUsers(): User[] {
    return SEED_USERS;
  },

  getAllUsers(): User[] {
    const creds = getStoredUsers();
    return creds.map((c) => c.user);
  },

  updateUserProfile(updates: Partial<User>): User | null {
    const current = this.getCurrentUser();
    if (!current) return null;

    const updated = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(updated));

    // Update in stored users registry too
    const all = getStoredUsers();
    const idx = all.findIndex((x) => x.user.id === updated.id);
    if (idx >= 0) {
      all[idx].user = updated;
      saveStoredUsers(all);
    }

    notifyAuth();
    return updated;
  },
};
