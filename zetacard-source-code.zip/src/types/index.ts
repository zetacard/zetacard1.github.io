export type CardCategory = 'business' | 'wedding' | 'birthday' | 'event' | 'restaurant';

export type CardStatus = 'published' | 'draft' | 'archived';

export type UserRole = 'admin' | 'user' | 'creator';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatarUrl?: string;
  bio?: string;
  company?: string;
  phone?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CardTheme {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  fontFamily: 'Inter' | 'Space Grotesk' | 'Outfit' | 'Playfair Display' | 'Cinzel' | 'Great Vibes';
  cardStyle: 'glass' | 'minimal' | 'luxury' | 'cyber' | 'gradient' | 'classic' | 'brutalist' | 'neon' | 'artisan' | 'nature';
  borderRadius: 'none' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
  layout: 'standard' | 'floating' | 'banner' | 'compact';
}

export interface SocialLink {
  id: string;
  platform: 'linkedin' | 'twitter' | 'instagram' | 'github' | 'youtube' | 'tiktok' | 'facebook' | 'whatsapp' | 'telegram' | 'website' | 'email' | 'phone' | 'maps';
  url: string;
  label?: string;
}

export interface BusinessService {
  id: string;
  title: string;
  description: string;
  price?: string;
  icon?: string;
}

export interface WeddingDetails {
  brideName: string;
  groomName: string;
  weddingDate: string; // ISO date string
  ceremonyTime: string;
  receptionTime: string;
  venueName: string;
  venueAddress: string;
  mapsUrl: string;
  story: string;
  dressCode?: string;
  registryUrl?: string;
  liveStreamUrl?: string;
}

export interface BirthdayDetails {
  honoreeName: string;
  turningAge?: number;
  birthDate: string;
  partyTime: string;
  venueName: string;
  venueAddress: string;
  theme: string;
  customMessage: string;
  rsvpDeadline?: string;
}

export interface EventScheduleItem {
  time: string;
  title: string;
  speaker?: string;
  description?: string;
}

export interface EventSpeaker {
  name: string;
  role: string;
  company: string;
  avatarUrl: string;
}

export interface EventDetails {
  eventTitle: string;
  organizer: string;
  startDate: string;
  endDate?: string;
  location: string;
  virtualLink?: string;
  schedule: EventScheduleItem[];
  speakers: EventSpeaker[];
  ticketInfo?: {
    price: string;
    link?: string;
    badge?: string;
  };
}

export interface MenuCategory {
  id: string;
  name: string;
  description?: string;
}

export interface MenuItem {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  imageUrl?: string;
  tags: ('vegetarian' | 'vegan' | 'gluten_free' | 'spicy' | 'chef_special' | 'halal')[];
  isAvailable: boolean;
}

export interface Card {
  id: string;
  userId: string;
  slug: string;
  category: CardCategory;
  templateId: string;
  status: CardStatus;
  title: string;
  subtitle: string;
  bio: string;
  coverImageUrl: string;
  profileImageUrl: string;
  company?: string;
  jobTitle?: string;
  phone?: string;
  email?: string;
  website?: string;
  address?: string;
  mapsUrl?: string;
  socialLinks: SocialLink[];
  services?: BusinessService[];
  theme: CardTheme;
  weddingDetails?: WeddingDetails;
  birthdayDetails?: BirthdayDetails;
  eventDetails?: EventDetails;
  menuCategories?: MenuCategory[];
  menuItems?: MenuItem[];
  viewCount: number;
  qrScanCount: number;
  vCardDownloadCount: number;
  nfcEnabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Booking {
  id: string;
  cardId: string;
  cardTitle: string;
  ownerId: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  date: string;
  timeSlot: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes?: string;
  createdAt: string;
}

export interface Contact {
  id: string;
  ownerId: string;
  sourceCardId?: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  role?: string;
  tags: string[];
  notes?: string;
  status: 'new' | 'contacted' | 'client' | 'archived';
  createdAt: string;
}

export interface Enquiry {
  id: string;
  cardId: string;
  ownerId: string;
  senderName: string;
  senderEmail: string;
  senderPhone?: string;
  subject: string;
  message: string;
  status: 'unread' | 'read' | 'replied';
  createdAt: string;
}

export interface Task {
  id: string;
  userId: string;
  title: string;
  description?: string;
  priority: 'low' | 'medium' | 'high';
  dueDate: string;
  completed: boolean;
  category: 'work' | 'client' | 'event' | 'personal';
  createdAt: string;
}

export interface Template {
  id: string;
  name: string;
  category: CardCategory;
  description: string;
  previewImage: string;
  tags: string[];
  theme: CardTheme;
  sampleData: Partial<Card>;
}
