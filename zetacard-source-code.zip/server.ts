import express from "express";
import path from "path";
import dotenv from "dotenv";
import { fileURLToPath } from "url";
import { handleAiGeneration } from "./server/ai.ts";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Server-side AI generation proxy
app.post("/api/ai/generate", async (req, res) => {
  try {
    const result = await handleAiGeneration(req.body);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Failed to generate AI response" });
  }
});

// Serve static assets from built frontend
const distPath = path.resolve(__dirname, "dist");
app.use(express.static(distPath));

app.get("*", (req, res) => {
  res.sendFile(path.join(distPath, "index.html"));
});

app.listen(port, () => {
  console.log(`ZetaCard production server running on port ${port}`);
});
