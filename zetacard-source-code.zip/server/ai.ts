import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

export interface AiGenerateRequest {
  type: "tagline" | "bio" | "invitation" | "menu_item" | "custom";
  prompt: string;
  context?: {
    category?: string;
    businessName?: string;
    industry?: string;
    tone?: "professional" | "luxury" | "creative" | "friendly" | "festive";
    details?: string;
  };
}

export async function handleAiGeneration(body: AiGenerateRequest): Promise<{ text: string; error?: string }> {
  const ai = getAiClient();
  if (!ai) {
    return {
      text: "",
      error: "Gemini API key is not configured in the environment.",
    };
  }

  const { type, prompt, context } = body;
  let systemInstruction = "You are ZetaCard AI Copilot, a master copywriter and design strategist for digital cards, event invitations, and restaurant menus. Provide concise, high-impact, engaging content. Avoid clichés and unnecessary conversational filler. Return ready-to-use polished text.";

  let fullPrompt = prompt;

  if (type === "tagline") {
    systemInstruction += " Generate 3 to 5 catchy, memorable, professional taglines for the specified business or individual.";
    fullPrompt = `Generate captivating taglines for: "${context?.businessName || prompt}". Industry: ${context?.industry || "General"}. Tone: ${context?.tone || "professional"}. Details: ${context?.details || ""}`;
  } else if (type === "bio") {
    systemInstruction += " Write an engaging, polished 2-3 paragraph professional bio or business description.";
    fullPrompt = `Write a compelling bio for: "${context?.businessName || prompt}". Role/Industry: ${context?.industry || "Professional"}. Tone: ${context?.tone || "professional"}. Key points: ${context?.details || prompt}`;
  } else if (type === "invitation") {
    systemInstruction += " Write an elegant, heartfelt, and clear invitation message suitable for a digital card, including event details, warm welcome, and RSVP encouragement.";
    fullPrompt = `Write an invitation message for: "${prompt}". Category: ${context?.category || "Event"}. Tone: ${context?.tone || "festive"}. Details: ${context?.details || ""}`;
  } else if (type === "menu_item") {
    systemInstruction += " Generate mouth-watering culinary descriptions for restaurant menu items, highlighting ingredients, flavors, and appeal.";
    fullPrompt = `Write a delectable description for this dish/item: "${prompt}". Style: ${context?.industry || "Gourmet"}. Key ingredients: ${context?.details || ""}`;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: fullPrompt,
      config: {
        systemInstruction,
      },
    });

    const text = response.text || "";
    return { text };
  } catch (err: any) {
    console.error("Gemini API error:", err);
    return {
      text: "",
      error: err?.message || "Failed to generate content with Gemini AI.",
    };
  }
}
